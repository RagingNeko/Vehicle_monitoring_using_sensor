<?php
// Database credentials
$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "db_booking_system"; // Your database name

// Create a connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect form data
    $first_name = isset($_POST['first_name']) ? trim($_POST['first_name']) : null;
    $last_name = isset($_POST['last_name']) ? trim($_POST['last_name']) : null;
    $sex = isset($_POST['sex']) ? trim($_POST['sex']) : null;
    $birthdate = isset($_POST['birthdate']) ? trim($_POST['birthdate']) : null;
    $age = isset($_POST['age']) ? trim($_POST['age']) : null;
    $building = isset($_POST['building']) ? trim($_POST['building']) : null;
    $street = isset($_POST['street']) ? trim($_POST['street']) : null;
    $barangay = isset($_POST['barangay']) ? trim($_POST['barangay']) : null;
    $city = isset($_POST['city']) ? trim($_POST['city']) : null;
    $province = isset($_POST['province']) ? trim($_POST['province']) : null;
    $email = isset($_POST['email']) ? trim($_POST['email']) : null;
    $username = isset($_POST['username']) ? trim($_POST['username']) : null;
    $password = isset($_POST['password']) ? trim($_POST['password']) : null;
    $agreed_to_terms = isset($_POST['agree']) ? 1 : 0;


    // Check for empty values and handle accordingly
    if (empty($first_name) || empty($last_name) || empty($sex) || empty($birthdate) || empty($age) || empty($street) || empty($barangay) || empty($city) || empty($province) || empty($email) || empty($username) || empty($password)) {
        die('Some fields are missing.');
    }

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO customer_account (first_name, last_name, sex, birthdate, age, building, street, barangay, city, province, email, username, password, agreed_to_terms) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssissssssssi", $first_name, $last_name, $sex, $birthdate, $age, $building, $street, $barangay, $city, $province, $email, $username, $password, $agreed_to_terms);

    // Execute the statement
    if ($stmt->execute()) {
        header("Location: index.php");
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close connections
    $stmt->close();
    $conn->close();
}
?>
