//
i was in the process of creating website for entertainer booking system. i want you to help in creating this system. 
i have the php files namely calendar.js, config.php, db_connect.php, entertainer-dashboardpage.php, entertainer-loginpage.php, getSchedule.php, scheduleAppointment.php. you will ask the code of each files i give you and i will give the code on each files. after i am done giving the code, you will ask me what help i need.



//

.container {
    display: flex;
    flex-direction: row;
    padding: 100px;
    margin-top: -5%;
}

.left-panel {
    width: 70%; /* Increased width */
    box-sizing: border-box;
    background-color: white;
    margin-right: 20px; /* Space between panels */
}

.right-panel {
    width: 30%; /* Reduced width */
    box-sizing: border-box;
    background-color: white;
}

.right-panel {
    margin-left: 20px; /* Optional: for consistency */
}



.left-panel .calendar {
    display: block;
}

.calendar-header {
    flex-direction: column;
    align-items: flex-start;
    margin-bottom: 15px;
}

.calendar-header button {
    width: 100%;
    margin-top: 10px;
}

.calendar-header h2 {
    font-size: 20px;
}

.calendar-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr); /* Seven columns for days of the week */
    gap: 5px; /* Space between days */
    margin-top: 10px;
}

.date-box {
    display: flex;
    flex-direction: column;
    align-items: center; /* Center the content horizontally */
    justify-content: center; /* Center the content vertically */
    height: 80px; /* Adjust height as needed */
    border: 1px solid #ddd; /* Optional: border for better visibility */
    background-color: #f9f9f9; /* Optional: background color for the date boxes */
}

.day-number {
    font-size: 18px; /* Larger font size for day numbers */
    margin-bottom: 5px; /* Space between day number and booking button */
}

.book-now {
    font-size: 12px;
    padding: 4px;
}


.legend {
    margin-top: 15px;
}

.legend p {
    margin: 3px 0;
}

.right-panel h2 {
    font-size: 20px;
}

.form-group input[type="text"], .form-group input[type="date"], .form-group button {
    font-size: 14px;
}

.form-group button {
    padding: 8px;
}

/* Media Query for Mobile Devices */
@media (max-width: 600px) {
    .container {
        flex-direction: row;
    }

    .left-panel, .right-panel {
        width: 100%;
        margin: 0;
    }
    
    .left-panel {
        margin-bottom: 20px;
    }
    
    .right-panel {
        margin-bottom: 0;
    }
    
    .calendar-grid {
        grid-template-columns: repeat(2, 1fr);
    }
}