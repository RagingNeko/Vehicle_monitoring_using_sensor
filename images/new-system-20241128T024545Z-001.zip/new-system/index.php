<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="style.css" rel="stylesheet">
</head>

<style>
    body, html {
        height: 100%; /* Full height for body and html */
        margin: 0; /* Remove default margin */
    }

    .main-content {
        display: flex; /* Use flexbox for layout */
        height: 100vh; /* Full viewport height */
    }

    .video-carousel {
        flex: 1; /* Allow the video carousel to take remaining space */
        display: flex; /* Align its children */
        align-items: center; /* Center vertically */
        justify-content: center; /* Center horizontally */
        height: 100%; /* Full height */
        overflow: hidden; /* Hide overflow */
    }

    .video-carousel video {
    width: 100%; /* Full width of the carousel */
    height: 450px; /* Increased height for the videos */
    object-fit: cover; /* Maintain aspect ratio and cover the area */
    }

    .carousel-inner {
        width: 100%; /* Make sure carousel takes full width */
        max-height: 100%; /* Restrict to full height */
    }

    .carousel-item {
    transition: none !important; /* Disable transition effects */
}

    .login-container {
    background: rgba(240, 240, 240, 0.9);
    padding: 30px;
    border-radius: 8px;
    box-shadow: 0 0 15px rgba(0, 0, 139, 0.5); /* Darker shadow */
    width: 300px; /* Fixed width */
    text-align: center;
    box-sizing: border-box;
    margin: auto; /* Center vertically in the flexbox */
    margin-right: 150px; /* Adjust this value to move the container left (decrease for more left) */
    margin-top: 10%;
}

    h1 {
        margin-bottom: 20px;
        color: #222; /* Darker text color */
        text-shadow:
            1px 1px 0 #fff,
            -1px -1px 0 #fff,
            1px -1px 0 #fff,
            -1px 1px 0 #fff; /* White outline effect */
    }

    .account-type {
        margin-bottom: 20px;
    }

    .account-type a {
        display: block;
        width: calc(100% - 20px);
        padding: 15px;
        margin: 10px auto;
        border-radius: 4px;
        color: white;
        text-decoration: none;
        font-size: 16px;
        text-align: center;
        background-color: #6c757d;
        transition: background-color 0.3s, transform 0.3s;
        box-sizing: border-box;
    }

    .account-type a:hover {
        background-color: #004494; /* Even darker blue for hover */
        transform: scale(1.05);
    }

    .navbar-brand img {
        width: 40px; /* Adjust size as needed */
        height: 40px; /* Adjust size as needed */
        border-radius: 40%; /* Make the image circular */
    }
</style>

<body>
    <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="#">
            <img src="images/logo.jpg" alt="Brand Logo"> <!-- Update the path to your image -->
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="aboutus.php">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link btn" href="signuppage.php">Signup</a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="container-fluid main-content">
        <div class="video-carousel">
            <div id="videoCarousel" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
    <div class="carousel-item active">
        <video class="d-block w-100" controls autoplay muted>
            <source src="video/video1.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        <div class="carousel-caption d-none d-md-block">
            <h1>Make appointment today!</h1>
            <p>Reach your favorite entertainer through us.</p>
        </div>
    </div>
    <div class="carousel-item">
        <video class="d-block w-100" controls autoplay muted>
            <source src="video/video2.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        <div class="carousel-caption d-none d-md-block">
            <h1>Discover Amazing Entertainers!</h1>
            <p>Find the best artists for your events.</p>
        </div>
    </div>
    <div class="carousel-item">
        <video class="d-block w-100" controls autoplay muted>
            <source src="video/video3.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        <div class="carousel-caption d-none d-md-block">
            <h1>Experience Great Moments!</h1>
            <p>Join us to make unforgettable memories.</p>
        </div>
    </div>
</div>
                <a class="carousel-control-prev" href="#videoCarousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#videoCarousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
        </div>
        
        <div class="login-container">
            <h1>Login as:</h1>
            <div class="account-type">
                <a href="customer/customer-loginpage.php">Customer</a>
                <a href="entertainer/entertainer-loginpage.php">Entertainer</a>
                <a href="admin/admin-loginpage.php">Manager</a>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>

</html>