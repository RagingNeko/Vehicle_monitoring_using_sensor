<?php
session_start();
include 'db_connect.php'; // Include the database connection

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Prepare and bind
    $stmt = $conn->prepare("SELECT password, first_name FROM admin_account WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // Check if the user exists
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($stored_password, $first_name);
        $stmt->fetch();

        // Compare the passwords
        if ($password === $stored_password) {
            // Password is correct, set session variables or redirect as needed
            $_SESSION['first_name'] = $first_name; // Store first_name in session
            header("Location: admin-appointments.php"); // Redirect to a welcome page
            exit();
        } else {
            $error = "Invalid password";
        }
    } else {
        $error = "No account found with that username";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manager Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f1f1f1;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            padding: 10px;
        }

        form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 400px;
            width: 100%;
            box-sizing: border-box;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
            font-size: 24px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #555;
        }

        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        input[type="text"]:hover, input[type="password"]:hover {
            border-color: #007bff;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.25);
        }

        input[type="submit"] {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s, box-shadow 0.3s;
            width: 100%;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
            box-shadow: 0 0 8px rgba(0, 123, 255, 0.5);
        }

        /* Responsive Styles */
        @media (max-width: 600px) {
            form {
                padding: 15px;
                box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            }

            h1 {
                font-size: 20px;
                margin-bottom: 15px;
            }

            input[type="text"], input[type="password"] {
                padding: 8px;
                margin-bottom: 10px;
            }

            input[type="submit"] {
                padding: 8px 12px;
                font-size: 14px;
            }
        }

        @media (max-width: 400px) {
            h1 {
                font-size: 18px;
                margin-bottom: 10px;
            }

            input[type="text"], input[type="password"] {
                padding: 6px;
                margin-bottom: 8px;
            }

            input[type="submit"] {
                padding: 6px 10px;
                font-size: 12px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="admin-loginpage.php" method="post">
            <h1>Manager Login</h1>
            <?php
            // Display the error message above the username field with the new font size
            if (!empty($error)) {
                echo "<p class='error-message'>$error</p>";
            }
            ?>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>
