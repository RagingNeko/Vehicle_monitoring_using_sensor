<?php
session_start();
include 'db_connect.php'; // Include the database connection if not already included

// Check if user is logged in
if (!isset($_SESSION['first_name'])) {
    header("Location: admin-loginpage.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Fetch and sanitize the data
    $entertainer_id = intval($_POST['entertainer_id']);
    $profile_image = htmlspecialchars($_POST['profile_image']);
    $first_name = htmlspecialchars($_POST['first_name']);
    $last_name = htmlspecialchars($_POST['last_name']);
    $title = htmlspecialchars($_POST['title']);
    $status = htmlspecialchars($_POST['status']);

    // Prepare the update statement
    $sql = "UPDATE entertainer_account SET profile_image= ?, first_name = ?, last_name = ?, title = ?, status = ? WHERE entertainer_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssi", $profile_image, $first_name, $last_name, $title, $status, $entertainer_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Update successful!";
        $_SESSION['msg_type'] = "success"; // Set message type for success
    } else {
        $_SESSION['message'] = "There was an error updating the entertainer. Please try again.";
        $_SESSION['msg_type'] = "error"; // Set message type for error
    }

    $stmt->close();
    $conn->close();

    // Redirect back to the entertainer list page
    header("Location: admin-entertainer.php");
    exit();
}
?>