
<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['first_name'])) {
    header("Location: admin-loginpage.php"); // Redirect to login page if not logged in
    exit();
}

$first_name = htmlspecialchars($_SESSION['first_name']); // Retrieve and sanitize the first_name

// Database connection
$host = 'localhost'; // Your database host
$dbname = 'db_booking_system'; // Your database name
$username = 'root'; // Your database username
$password = ''; // Your database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Fetch data from booking_report table
   // Fetch data from booking_report table
$stmt = $pdo->query("
SELECT br.book_id, 
       br.date_schedule, 
       br.customer_name, 
       br.price_offer, 
       br.street, 
       br.barangay, 
       br.municipality, 
       br.province, 
       br.status, 
       br.time_start, 
       br.time_end, 
       e.title AS entertainer_title, 
       br.contact_number, 
       br.email 
FROM booking_report br
LEFT JOIN entertainer_account e ON br.entertainer_id = e.entertainer_id
");
    $appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Dashboard</title>
    <link rel="stylesheet" href="style1.css">
</head>
<style>
         body {
            overflow: auto; /* Only show scrollbar when necessary */
        }

        .content {
            overflow: hidden; /* Hide scrollbar initially */
        }

        /* Show scrollbar when content overflows */
        .content::-webkit-scrollbar {
            width: 0;
            height: 0;
        }

        .content {
            overflow-y: auto;
        }

            /* Schedule List Styles */
        .content {
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: flex-start; /* Align items at the top */
            margin-left: 20px;
            padding: 20px;
            padding-top: 20px; /* Give some space below the header */
            background-color: #f2f2f2;
            min-height: 100vh;
        }

        .schedule-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 100%; /* Ensure it takes full width of the parent */
            max-width: 1200px; /* Set a maximum width for larger screens */
        }


        .schedule-container input[type="text"] {
            padding: 10px;
            width: 40%;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .schedule-header {
            background-color: #fff;
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 10px 10px 0 0;
        }

        .schedule-header h2 {
            margin: 0;
            font-size: 18px;
            color: #333;
        }

        .schedule-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .schedule-table th, .schedule-table td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
            color: #333;
        }

        .schedule-table th {
            background-color: #f8f8f8;
            font-weight: normal;
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .pagination select {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .pagination span {
            color: #888;
        }

        .pagination-controls {
            display: flex;
            gap: 5px;
        }

        .pagination-controls img {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .header {
                width: 100%;
                left: 0;
            }

            .content {
                margin-left: 0;
                padding-top: 60px; /* Adjust padding for smaller screens */
                padding: 10px; /* Add padding to the content */
            }

            .schedule-container {
                width: 100%; /* Full width for small screens */
                padding: 10px; /* Adjust padding */
            }

            .schedule-header input[type="text"] {
                width: 100%; /* Full width input for smaller screens */
            }

            .pagination {
                flex-direction: row; /* Stack pagination controls vertically */
                align-items: flex-start;
            }

            .pagination-controls {
                width: 100%;
                justify-content: space-between; /* Space out controls */
            }
        }


        .button-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .schedule-header .refresh-btn
         {
            width: 40px;
            height: 40px;
            border: none;
            background-color: white;
            color: black;
            font-size: 18px;
            border-radius: 50%;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .schedule-header .refresh-btn:hover
        {
            background-color: #f0fff0;
        }

        #status-select {
            padding: 10px;
            width: 30%;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 20px; /* Space between dropdown and table */
        }

        .nav-items {
            display: flex;
            gap: 30px; /* Space between items */
            margin-right: 80px; /* Adjust this value to increase space from the profile image */
        }

        .nav-items a {
            text-decoration: none;
            color: white; /* Adjust color as needed */
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .nav-items a:hover {
            background-color: #87CEFA; /* Light blue background on hover */
            text-decoration: none; /* Ensure no underline on hover */
            color: black;
        }

        .dropbtn {
            background: none; /* Remove default button background */
            border: none; /* Remove default button border */
            cursor: pointer; /* Pointer cursor on hover */
        }

        .dropbtn img {
            width: 40px; /* Adjust image size */
            height: auto; /* Maintain aspect ratio */
        }

        .navbar-brand img {
                    width: 40px; /* Adjust size as needed */
                    height: 40px; /* Adjust size as needed */
                    border-radius: 40%; /* Make the image circular */
                }

        .action-btn {
            padding: 6px 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        .view-btn {
            background-color: lightgray; /* Light gray for view button */
            color: black;
        }

        .approve-btn {
            background-color: green; /* Green for approve button */
            color: white;
        }

        .decline-btn {
            background-color: red; /* Red for decline button */
            color: white;
        }

        .action-btn:hover {
            opacity: 0.8; /* Add hover effect for buttons */
        }

/* Add modal styles */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1000; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.7); /* Dark background with more opacity */
}

.modal-content {
    background-color: #fff;
    margin: 60px auto; /* Center modal with 50px margin from the top */
    padding: 20px;
    border: 1px solid #888;
    width: 80%; /* Could be more or less, depending on screen size */
    max-width: 600px; /* Limit the maximum width */
    border-radius: 8px; /* Rounded corners */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Box shadow for depth */
    position: relative; /* Position relative for absolute positioned close button */
}

.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer; /* Pointer cursor on hover */
}

.close:hover,
.close:focus {
    color: #ff3333; /* Change color on hover */
    text-decoration: none;
    outline: none;
}

/* Heading styles */
.modal-content h2 {
    margin: 0;
    color: #333;
    font-size: 24px;
}

.modal-content h2 {
    margin: 0;
    color: #333;
    font-size: 24px;
    text-align: center; /* Center the heading text */
}

/* Details Styling */
#modalDetails {
    padding: 10px 0; /* Add padding for better spacing */
}

/* Additional styling for detail paragraphs */
#modalDetails p {
    padding: 8px 0;
    border-bottom: 1px solid #ddd; /* Optional border below each detail */
    margin: 8px 0;
}

/* Last detail styling */
#modalDetails p:last-child {
    border-bottom: none; /* Remove border from last element */
}
</style>
<body>
    <header>
    <a class="navbar-brand" href="#">
            <img src="../images/logo.jpg" alt="Brand Logo"> <!-- Update the path to your image -->
        </a>
        <nav>
        <div class="nav-items">
                <a href="admin-appointments.php">Appointment List</a>
                <a href="admin-entertainer.php">Entertainer List</a>
            </div>
            <div class="dropdown" id="dropdown">
                <button class="dropbtn" onclick="toggleDropdown()">
                    <img src="../images/sample.jpg" alt="Profile"> <!-- Replace with your image -->
                </button>
                <div class="dropdown-content" id="dropdown-content">
                    <a href="admin-profile.php">View Profile</a>
                    <a href="logout.php">Logout</a> <!-- Logout link pointing to logout.php -->
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="welcome-message">
            <h1>Welcome, <?php echo $first_name; ?>!</h1>
            <p>We’re glad to have you here. Let’s get started!</p>
        </section>
    </main>

    <div class="content">
        <div class="schedule-container">
            <h2>Appointments</h2>
            <div class="schedule-header">
                <select id="status-select">
                    <option value="">Select Status</option>
                    <option value="Approved">Approved</option>
                    <option value="Pending">Pending</option>
                    <option value="Decline">Declined</option>
                    <!-- Add more status options as needed -->
                </select>
                <div class="button-group">
                    <button class="refresh-btn" aria-label="Refresh">⟳</button>
                </div>
            </div>
            <table class="schedule-table">
                <thead>
                    <tr>
                        <th>Date Schedule</th>
                        <th>Customer Name</th>
                        <th>Price Offer</th>
                        <th>Venue</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="schedule-table-body">
    <?php if (!empty($appointments)): ?>
        <?php foreach ($appointments as $appointment): ?>
            <tr>
                <td><?php echo htmlspecialchars($appointment['date_schedule']); ?></td>
                <td><?php echo htmlspecialchars($appointment['customer_name']); ?></td>
                <td><?php echo htmlspecialchars($appointment['price_offer']); ?></td>
                <td>
                    <?php
                        echo htmlspecialchars($appointment['street']) . ', ' .
                             htmlspecialchars($appointment['barangay']) . ', ' .
                             htmlspecialchars($appointment['municipality']) . ', ' .
                             htmlspecialchars($appointment['province']);
                    ?>
                </td>
                <td><?php echo htmlspecialchars($appointment['status']); ?></td> 
                <td>
                    <button class="action-btn view-btn" data-details="<?php echo htmlspecialchars(json_encode($appointment)); ?>">View Details</button>
                    <button class="action-btn approve-btn" data-id="<?php echo htmlspecialchars($appointment['book_id']); ?>">Approve</button>
                    <button class="action-btn decline-btn" data-id="<?php echo htmlspecialchars($appointment['book_id']); ?>">Decline</button>
                    <button class="action-btn cancel-btn" style="display: none;">Cancel</button>
                    <button class="action-btn undo-btn" style="display: none;">Undo</button>
                </td>
            </tr>
        <?php endforeach; ?>
    <?php else: ?>
        <tr>
            <td colspan="5">No appointments available.</td>
        </tr>
    <?php endif; ?>
</tbody>
            </table>

            <div id="no-status-message" style="display: none; text-align: center; margin-top: 20px;">
    <strong>No appointments available for the selected status.</strong>
</div>

            <div class="pagination">
                <div>
                    <label for="items-per-page">Items per page:</label>
                    <select id="items-per-page">
                        <option value="10">10</option>
                        <option value="20">20</option>
                        <option value="30">30</option>
                    </select>
                </div>
                <div class="page-controls">
                    <button disabled aria-label="Previous Page">◀</button>
                    <span id="pagination-info">0-0 of 0</span>
                    <button disabled aria-label="Next Page">▶</button>
                </div>
            </div>
        </div>
    </div>

 <!-- The Modal -->
 <div id="myModal" class="modal">
        <!-- Modal content -->
        <div class="modal-content">
            <span class="close" id="closeModal">&times;</span>
            <h2>Appointment Details</h2>
            <div id="modalDetails"></div>
        </div>
    </div>

    <script>
       
       document.querySelectorAll('.view-btn').forEach(button => {
    button.addEventListener('click', function() {
        const appointment = JSON.parse(this.getAttribute('data-details'));
        const modalDetails = document.getElementById('modalDetails');

        // Display appointment details in the modal
        modalDetails.innerHTML = `
            <p><strong>Date Schedule:</strong> ${appointment.date_schedule}</p>
            <p><strong>Time Start:</strong> ${appointment.time_start}</p>
            <p><strong>Time End:</strong> ${appointment.time_end}</p>
            <p><strong>Customer Name:</strong> ${appointment.customer_name}</p>
            <p><strong>Price Offer:</strong> ${appointment.price_offer}</p>
            <p><strong>Venue:</strong> ${appointment.street}, ${appointment.barangay}, ${appointment.municipality}, ${appointment.province}</p>
            <p><strong>Status:</strong> ${appointment.status}</p>
            <p><strong>Entertainer:</strong> ${appointment.entertainer_title}</p>
            <p><strong>Contact Number:</strong> ${appointment.contact_number}</p>
            <p><strong>Email:</strong> ${appointment.email}</p>
        `;

        // Show the modal
        document.getElementById('myModal').style.display = "block";
    });
});

        // Close the modal when the user clicks on <span> (x)
        document.getElementById('closeModal').onclick = function() {
            document.getElementById('myModal').style.display = "none";
        }

        // Close the modal when clicking outside of the modal
        window.onclick = function(event) {
            if (event.target == document.getElementById('myModal')) {
                document.getElementById('myModal').style.display = "none";
            }
        }

        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown');
            const dropdownContent = document.getElementById('dropdown-content');

            // Toggle the visibility of the dropdown content
            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            } else {
                // Close any other open dropdowns
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });

                dropdown.classList.add('show');
            }
        }

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn') && !event.target.matches('.dropbtn img')) {
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });
            }
        }

       // Filter appointments based on status selection
    document.getElementById('status-select').addEventListener('change', function() {
        const selectedStatus = this.value.toLowerCase(); // Get selected status
        const rows = document.querySelectorAll('#schedule-table-body tr');
        let hasVisibleRows = false; // Flag to track if any row is visible

        rows.forEach(row => {
            const statusCell = row.cells[4].textContent.toLowerCase(); // Update index according to your table
            if (selectedStatus === '' || statusCell === selectedStatus) {
                row.style.display = ''; // Show row
                hasVisibleRows = true; // At least one row is visible
            } else {
                row.style.display = 'none'; // Hide row
            }
        });

        // Show/hide the no status message based on visibility of rows
        const messageElement = document.getElementById('no-status-message');
        if (!hasVisibleRows) {
            messageElement.style.display = 'block'; // Show the message
        } else {
            messageElement.style.display = 'none'; // Hide the message
        }
    });

    document.querySelectorAll('.approve-btn').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr'); // Get the closest row that contains the button
        const book_id = this.getAttribute('data-id'); // Get the book ID directly from the approve button

        // Update status to "Approved" via AJAX
        fetch('update-status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `book_id=${book_id}&action=approve` // Send the action to approve
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update the status cell
                row.cells[4].textContent = 'Approved'; // Assuming the status cell index is 4

                // Update button visibility without refreshing
                this.style.display = 'none'; // Hide the approve button
                const declineButton = row.querySelector('.decline-btn');
                declineButton.style.display = 'none'; // Hide the decline button
                const cancelButton = row.querySelector('.cancel-btn');
                cancelButton.style.display = 'inline-block'; // Show the cancel button
            } else {
                console.error(data.message); // Log the error
                alert(data.message); // Alert user for any issue
            }
        })
        .catch(err => console.error('Fetch Error:', err));
    });
});

document.querySelectorAll('.cancel-btn').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr'); // Get the closest row that contains the button
        const book_id = row.querySelector('.approve-btn').getAttribute('data-id'); // Get book_id from approve button

        // Hide the cancel button
        this.style.display = 'none';

        // Show the approve button and decline button again
        const approveButton = row.querySelector('.approve-btn');
        const declineButton = row.querySelector('.decline-btn');
        approveButton.style.display = 'inline-block'; // Make it visible
        declineButton.style.display = 'inline-block'; // Make it visible

        // Update status to "Pending" via AJAX
        fetch('update-status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `book_id=${book_id}&action=cancel` // Include action for pending
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                row.cells[4].textContent = 'Pending'; // Update the status cell
            } else {
                console.error(data.message); // Log any errors
                alert(data.message); // Optionally alert the user
            }
        })
        .catch(err => console.error('Fetch Error:', err));
    });
});

// Refresh button event listener
// Refresh button event listener
document.querySelector('.refresh-btn').addEventListener('click', function() {
    const rows = document.querySelectorAll('#schedule-table-body tr');

    rows.forEach(row => {
        const statusCell = row.cells[4].textContent; // Getting the status from the 5th column

        // Update button visibility according to the status
        if (statusCell === 'Approved') {
            row.querySelector('.approve-btn').style.display = 'none'; // Hide approve button
            row.querySelector('.decline-btn').style.display = 'none'; // Hide decline button
            row.querySelector('.cancel-btn').style.display = 'inline-block'; // Show cancel button
        } else if (statusCell === 'Declined') {
            row.querySelector('.approve-btn').style.display = 'none'; // Hide approve button
            row.querySelector('.decline-btn').style.display = 'none'; // Hide decline button
            row.querySelector('.undo-btn').style.display = 'inline-block'; // Show undo button
        } else { // For Pending statuses
            row.querySelector('.approve-btn').style.display = 'inline-block'; // Show approve button
            row.querySelector('.decline-btn').style.display = 'inline-block'; // Show decline button
            row.querySelector('.cancel-btn').style.display = 'none'; // Hide cancel button
            row.querySelector('.undo-btn').style.display = 'none'; // Ensure undo is hidden
        }
    });
});

// Function to update button visibility based on appointment status
function updateButtonVisibility() {
    const rows = document.querySelectorAll('#schedule-table-body tr');

    rows.forEach(row => {
        const statusCell = row.cells[4].textContent; // Adjust index according to your table

        if (statusCell === 'Approved') {
            row.querySelector('.approve-btn').style.display = 'none'; // Hide approve button
            row.querySelector('.decline-btn').style.display = 'none'; // Hide decline button
            row.querySelector('.cancel-btn').style.display = 'inline-block'; // Show cancel button
        } else if (statusCell === 'Declined') {
            row.querySelector('.approve-btn').style.display = 'none'; // Hide approve button
            row.querySelector('.decline-btn').style.display = 'none'; // Hide decline button
            row.querySelector('.undo-btn').style.display = 'inline-block'; // Show undo button
        } else { // For Pending statuses
            row.querySelector('.approve-btn').style.display = 'inline-block'; // Show approve button
            row.querySelector('.decline-btn').style.display = 'inline-block'; // Show decline button
            row.querySelector('.cancel-btn').style.display = 'none'; // Hide cancel button
            row.querySelector('.undo-btn').style.display = 'none'; // Ensure undo is hidden
        }
    });
}

// Call this function on initial page load or data fetch to set button visibility correctly
updateButtonVisibility();

// Call updateButtonVisibility on page load
document.addEventListener('DOMContentLoaded', (event) => {
    updateButtonVisibility();
});

// Refresh button event listener
document.querySelector('.refresh-btn').addEventListener('click', function() {
    updateButtonVisibility(); // Call the function on refresh
});

document.querySelectorAll('.decline-btn').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr'); // Get the closest row that contains the button
        const book_id = this.getAttribute('data-id'); // Get the book ID directly from the decline button

        // Update status to "Declined" via AJAX
        fetch('update-status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `book_id=${book_id}&action=decline` // Send the action to decline
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                // Update the status cell
                row.cells[4].textContent = 'Declined'; // Assuming the status cell index is 4

                // Update button visibility without refreshing
                this.style.display = 'none'; // Hide the decline button
                const approveButton = row.querySelector('.approve-btn');
                approveButton.style.display = 'none'; // Hide the approve button
                const undoButton = row.querySelector('.undo-btn');
                undoButton.style.display = 'inline-block'; // Show the undo button
            } else {
                console.error(data.message); // Log the error
                alert(data.message); // Alert user for any issue
            }
        })
        .catch(err => console.error('Fetch Error:', err));
    });
});

// Undo button functionality
document.querySelectorAll('.undo-btn').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr'); // Get the closest row that contains the button
        const book_id = row.querySelector('.approve-btn').getAttribute('data-id'); // Get book_id from approve button

        // Hide the undo button
        this.style.display = 'none';

        // Show the approve button and decline button again
        const approveButton = row.querySelector('.approve-btn');
        const declineButton = row.querySelector('.decline-btn');
        approveButton.style.display = 'inline-block'; // Make it visible
        declineButton.style.display = 'inline-block'; // Make it visible

        // Update status to "Pending" via AJAX
        fetch('update-status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `book_id=${book_id}&action=undo` // Include action for pending
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                row.cells[4].textContent = 'Pending'; // Update the status cell
            } else {
                console.error(data.message); // Log any errors
                alert(data.message); // Optionally alert the user
            }
        })
        .catch(err => console.error('Fetch Error:', err));
    });
});


    </script>
</body>
</html>