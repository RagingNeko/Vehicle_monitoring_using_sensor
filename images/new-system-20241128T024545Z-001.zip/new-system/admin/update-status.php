<?php
session_start();
$host = 'localhost';
$dbname = 'db_booking_system';
$username = 'root'; // Change as needed
$password = ''; // Change as needed

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if (isset($_POST['book_id']) && isset($_POST['action'])) {
        $book_id = intval($_POST['book_id']);
        $action = $_POST['action']; // Get the action type (approve, decline, or cancel)

        // Check if the book_id exists before updating
        $checkStmt = $pdo->prepare("SELECT COUNT(*) FROM booking_report WHERE book_id = :book_id");
        $checkStmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
        $checkStmt->execute();
        $exists = $checkStmt->fetchColumn();

        if ($exists > 0) {
            if ($action === 'approve') {
                $stmt = $pdo->prepare("UPDATE booking_report SET status = 'Approved' WHERE book_id = :book_id");
            } elseif ($action === 'cancel') {
                $stmt = $pdo->prepare("UPDATE booking_report SET status = 'Pending' WHERE book_id = :book_id");
            } elseif ($action === 'undo') {
                $stmt = $pdo->prepare("UPDATE booking_report SET status = 'Pending' WHERE book_id = :book_id");
            } elseif ($action === 'decline') {
                $stmt = $pdo->prepare("UPDATE booking_report SET status = 'Declined' WHERE book_id = :book_id");
            } else {
                // Handle unknown action type
                echo json_encode(['status' => 'error', 'message' => 'Invalid action type.']);
                exit();
            }
            $stmt->bindParam(':book_id', $book_id, PDO::PARAM_INT);
            $stmt->execute();

            if ($stmt->rowCount() > 0) {
                echo json_encode(['status' => 'success']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'No rows updated.']);
            }
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Book ID not found.']);
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'No book ID provided']);
    }
} catch (PDOException $e) {
    file_put_contents('error_log.txt', $e->getMessage(), FILE_APPEND);
    echo json_encode(['status' => 'error', 'message' => 'Database error occurred.']);
}
?>