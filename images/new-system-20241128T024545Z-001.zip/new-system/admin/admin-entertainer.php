<?php
session_start();
include 'db_connect.php'; // Include the database connection

// Check if the user is logged in
if (!isset($_SESSION['first_name'])) {
    header("Location: admin-loginpage.php"); // Redirect to login page if not logged in
    exit();
}

$first_name = htmlspecialchars($_SESSION['first_name']); // Retrieve and sanitize the first_name

// Fetch data from the database
$entertainers = [];
$items_per_page = isset($_GET['items-per-page']) ? intval($_GET['items-per-page']) : 10;
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$offset = ($page - 1) * $items_per_page;

$sql = "SELECT * FROM entertainer_account LIMIT ? OFFSET ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $items_per_page, $offset);
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $entertainers[] = $row;
}
$stmt->close();

// Count total records for pagination
$total_result = $conn->query("SELECT COUNT(*) as total FROM entertainer_account");
$total_row = $total_result->fetch_assoc();
$total_records = $total_row['total'];
$total_pages = ceil($total_records / $items_per_page);

$conn->close();

// Check for success or error messages
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    $msg_type = $_SESSION['msg_type'];
    // Clear the message after displaying
    unset($_SESSION['message']);
    unset($_SESSION['msg_type']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Dashboard</title>
    <link rel="stylesheet" href="style1.css">
</head>
<style>
         body {
            overflow: auto; /* Only show scrollbar when necessary */
        }

        .content {
            overflow: hidden; /* Hide scrollbar initially */
        }

        /* Show scrollbar when content overflows */
        .content::-webkit-scrollbar {
            width: 0;
            height: 0;
        }

        .content {
            overflow-y: auto;
        }

            /* Schedule List Styles */
        .content {
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: flex-start; /* Align items at the top */
            margin-left: 20px;
            padding: 20px;
            padding-top: 20px; /* Give some space below the header */
            background-color: #f2f2f2;
            min-height: 100vh;
        }

        .schedule-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 100%; /* Ensure it takes full width of the parent */
            max-width: 1200px; /* Set a maximum width for larger screens */
        }

        .search-container {
            display: flex;
            justify-content: space-between; /* Space between input and buttons */
            align-items: center; /* Align items vertically */
            margin-bottom: 20px;
            width: 100%;
        }

        .search-container input[type="text"] {
            
            margin-right: 20px; /* Space between input and buttons */
            padding: 10px;
            width: 30%;
            margin-left: 10px;
        }

        .button-group {
            display: flex;
            gap: 10px; /* Space between buttons */
        }

        .refresh-btn, .add-btn {
    background: #f0f0f0; /* Same background color */
    border: none; /* Remove default border */
    padding: 10px; /* Add padding for both buttons */
    border-radius: 4px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    text-align: center; /* Center the text */
    text-decoration: none; /* Remove underline for the anchor */
    color: black; /* Text color */
    font-size: 18px; /* Font size */
    transition: background-color 0.3s; /* Smooth transition on hover */
}

.add-btn:hover, .refresh-btn:hover {
    background-color: #87CEFA; /* Light blue background on hover */
    color: black; /* Text color on hover */
}

        .button-group button {
            background: #f0f0f0;
            border: none;
            padding: 10px;
            border-radius: 4px;
            cursor: pointer;
        }

        .schedule-header {
            background-color: #fff;
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 10px 10px 0 0;
        }

        .schedule-header h2 {
            margin: 0;
            font-size: 18px;
            color: #333;
        }

        .schedule-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .schedule-table th, .schedule-table td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
            color: #333;
        }

        .schedule-table th {
            background-color: #f8f8f8;
            font-weight: normal;
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            
        }

        .pagination select {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .pagination span {
            color: #888;
        }

        .pagination-controls {
            display: flex;
            gap: 5px;
        }

        .pagination-controls img {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .header {
                width: 100%;
                left: 0;
            }

            .content {
                margin-left: 0;
                padding-top: 60px; /* Adjust padding for smaller screens */
                padding: 10px; /* Add padding to the content */
            }


            .pagination {
                flex-direction: row; /* Stack pagination controls vertically */
                align-items: flex-start;
            }

            .pagination-controls {
                width: 100%;
                justify-content: space-between; /* Space out controls */
            }
        }

        .nav-items {
            display: flex;
            gap: 30px; /* Space between items */
            margin-right: 80px; /* Adjust this value to increase space from the profile image */
        }

        .nav-items a {
            text-decoration: none;
            color: white; /* Adjust color as needed */
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .nav-items a:hover {
            background-color: #87CEFA; /* Light blue background on hover */
            text-decoration: none; /* Ensure no underline on hover */
            color: black;
        }

        .dropbtn {
            background: none; /* Remove default button background */
            border: none; /* Remove default button border */
            cursor: pointer; /* Pointer cursor on hover */
        }

        .dropbtn img {
            width: 40px; /* Adjust image size */
            height: auto; /* Maintain aspect ratio */
        }

        .navbar-brand img {
                    width: 40px; /* Adjust size as needed */
                    height: 40px; /* Adjust size as needed */
                    border-radius: 40%; /* Make the image circular */
                }

.modal {
    position: fixed;
    z-index: 1000;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Form group styling */
.form-group {
    margin-bottom: 15px; /* Add space between fields */
    width: 100%;
}

/* Modal container */
#editModal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 9999;
}

/* Modal content */
.modal-content {
    background: white;
    padding: 40px;
    border-radius: 8px;
    max-width: 500px; /* Maximum width for the modal */
    width: 90%; /* Full width on smaller screens */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    position: relative;
    text-align: center;
}

.edit-button {
    background-color: #007bff; /* Bootstrap primary blue color */
    color: white; /* White text */
    border: none; /* Remove default border */
    padding: 10px 15px; /* Top and bottom padding of 10px, left and right padding of 15px */
    border-radius: 4px; /* Rounded corners */
    cursor: pointer; /* Cursor changes to pointer on hover */
    font-size: 16px; /* Larger font size */
    transition: background-color 0.3s, transform 0.1s; /* Smooth transition for background color and transform */
    display: inline-flex; /* Allows centering of icon if needed */
    align-items: center; /* Vertically centers items, if an icon is added */
}

.edit-button:hover {
    background-color: #0056b3; /* Darker blue on hover */
    transform: scale(1.05); /* Slightly increase size on hover */
}

.edit-button:focus {
    outline: none; /* Remove default focus outline */
    box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.5); /* Add a custom focus ring */
}

/* Modal close button */
.close-btn {
    color: #aaa;
    float: right; /* Float to the right */
    font-size: 28px;
    font-weight: bold;
    margin-top: -10px; /* To adjust positioning */
    margin-right: -10px; /* To adjust positioning */
    cursor: pointer; /* Indicate it's clickable */
}

.close-btn:hover,
.close-btn:focus {
    color: #000; /* Change color on hover */
    text-decoration: none;
    cursor: pointer;
}

/* Form styles */
.form-group {
    margin-bottom: 15px;
}

label {
    font-weight: bold;
    color: #333;
    display: block; /* Makes label take full line width */
    margin-bottom: 5px; /* Adding some space below the label */
    text-align: left; /* Aligns text to the left */
}

input[type="text"],
input[type="password"],
select {
    width: calc(100% - 20px); /* Full width minus padding */
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-sizing: border-box; /* Include padding in width */
    font-size: 14px; /* Adjust font size */
    margin-left: -20px;
}

#items-per-page{
    margin-left: 5px;
}

/* Button styles */
.form-actions {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
}

.submit-button,
.cancel-button {
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s;
}

.submit-button {
    background-color: #007bff; /* Primary blue */
    color: white;
}

.submit-button:hover {
    background-color: #0056b3; /* Darker blue on hover */
}

.cancel-button {
    background-color: #ccc; /* Gray for cancel */
    color: #333;
}

.cancel-button:hover {
    background-color: #aaa; /* Darker gray on hover */
}

/* Animation for modal */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

.message {
    padding: 10px;
    margin: 20px 0;
    border-radius: 5px;
    text-align: center;
}

.message.success {
    background-color: #d4edda; /* Light green background */
    color: #155724; /* Dark green text */
    border: 1px solid #c3e6cb; /* Green border */
}

.message.error {
    background-color: #f8d7da; /* Light red background */
    color: #721c24; /* Dark red text */
    border: 1px solid #f5c6cb; /* Red border */
}





</style>
<body>
    <header>
    <a class="navbar-brand" href="#">
            <img src="../images/logo.jpg" alt="Brand Logo"> <!-- Update the path to your image -->
        </a>
        <nav>
        <div class="nav-items">
                <a href="admin-appointments.php">Appointment List</a>
                <a href="admin-entertainer.php">Entertainer List</a>
            </div>
            <div class="dropdown" id="dropdown">
                <button class="dropbtn" onclick="toggleDropdown()">
                    <img src="../images/sample.jpg" alt="Profile"> <!-- Replace with your image -->
                </button>
                <div class="dropdown-content" id="dropdown-content">
                    <a href="admin-profile.php">View Profile</a>
                    <a href="logout.php">Logout</a> <!-- Logout link pointing to logout.php -->
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="welcome-message">
            <h1>Welcome, <?php echo $first_name; ?>!</h1>
            <p>We’re glad to have you here. Let’s get started!</p>
        </section>

        <?php if (isset($message)): ?>
            <div class="message <?php echo $msg_type; ?>" id="status-message">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <div class="content">
            <div class="schedule-container">
                <h2>Entertainer List</h2>

                <div class="search-container">
                <input type="text" id="search-input" placeholder="Search By Firstname" oninput="searchEntertainer()">
                    <div class="button-group">
                        <button class="refresh-btn" aria-label="Refresh" onclick="refreshList()">⟳</button>
                        <a href="add-entertainer.php" class="add-btn" aria-label="Add">+</a>
                    </div>
                </div>

                <table class="schedule-table">
                    <thead>
                        <tr>
                            <th>Profile</th>
                            <th>Firstname</th>
                            <th>Lastname</th>
                            <th>Title</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="schedule-table-body">
                        <?php foreach ($entertainers as $entertainer): ?>
                            <tr>
                            <td>
                                <img src="../images/<?php echo htmlspecialchars($entertainer['profile_image']); ?>" alt="Profile" width="50">
                            </td>

                                <td><?php echo htmlspecialchars($entertainer['first_name']); ?></td>
                                <td><?php echo htmlspecialchars($entertainer['last_name']); ?></td>
                                <td><?php echo htmlspecialchars($entertainer['title']); ?></td>
                                <td><?php echo htmlspecialchars($entertainer['status']); ?></td>
                                <td><button class="edit-button" onclick="viewDetails(<?php echo $entertainer['entertainer_id']; ?>)">Edit</button></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <div class="pagination">
                    <div>
                        <label for="items-per-page">Items per page:</label>
                        <select id="items-per-page" onchange="changeItemsPerPage(this.value)">
                            <option value="10" <?php echo $items_per_page == 10 ? 'selected' : ''; ?>>10</option>
                            <option value="20" <?php echo $items_per_page == 20 ? 'selected' : ''; ?>>20</option>
                            <option value="30" <?php echo $items_per_page == 30 ? 'selected' : ''; ?>>30</option>
                        </select>
                    </div>
                    <div class="page-controls">
                        <button <?php if ($page <= 1) echo 'disabled'; ?> onclick="changePage(<?php echo $page - 1; ?>)">◀</button>
                        <span id="pagination-info"><?php echo ($offset + 1) . '-' . min($offset + $items_per_page, $total_records) . ' of ' . $total_records; ?></span>
                        <button <?php if ($page >= $total_pages) echo 'disabled'; ?> onclick="changePage(<?php echo $page + 1; ?>)">▶</button>
                    </div>
                </div>
            </div>
        </div>
    </main>

<!-- Modal -->
<div id="editModal" class="modal" style="display:none;">
    <div class="modal-content">
       <span class="close-btn" onclick="closeModal('editModal')">&times;</span>
        <h2>Edit Entertainer</h2>
        <form id="editForm" method="post" action="update_entertainer.php">
    <input type="hidden" id="entertainerId" name="entertainer_id">
    
    <div class="form-group">
                <label for="profileImage">Profile Image:</label>
                <img id="currentProfileImage" src="" alt="Current Profile" width="50" style="margin-bottom: 10px;">
                <input type="file" id="profileImage" name="profile_image" accept="image/*">
            </div>

    <div class="form-group">
        <label for="firstName">First Name:</label>
        <input type="text" id="firstName" name="first_name" required>
    </div>
    <div class="form-group">
        <label for="lastName">Last Name:</label>
        <input type="text" id="lastName" name="last_name" required>
    </div>
    <div class="form-group">
        <label for="title">Title:</label>
        <input type="text" id="title" name="title" required>
    </div>
    <div class="form-group">
        <label for="status">Status:</label>
        <select id="status" name="status" required>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
        </select>
    </div>
    <div class="form-actions">
        <button type="submit" class="submit-button">Update Entertainer</button>
        <button type="button" class="cancel-button" onclick="closeModal('editModal')">Cancel</button>
    </div>
</form>
    </div>
</div>


    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown');
            const dropdownContent = document.getElementById('dropdown-content');

            // Toggle the visibility of the dropdown content
            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            } else {
                // Close any other open dropdowns
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });

                dropdown.classList.add('show');
            }
        }

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn') && !event.target.matches('.dropbtn img')) {
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });
            }
        }

        function refreshList() {
            // Reload the page to refresh the list
            window.location.reload();
        }

        function addEntertainer() {
            // Redirect to add entertainer page
            window.location.href = 'add-entertainer.php';
        }

        function viewDetails(id) {
    // Fetch data for the entertainer ID
    fetch(`fetch_entertainer.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            // Populate the modal with fetched data
            document.getElementById('entertainerId').value = data.entertainer_id;
            document.getElementById('firstName').value = data.first_name;
            document.getElementById('lastName').value = data.last_name;
            document.getElementById('title').value = data.title;
            document.getElementById('status').value = data.status;

            // Show the modal
            document.getElementById('editModal').style.display = 'flex';
        })
        .catch(error => console.error('Error fetching entertainer data:', error));
}

function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}




        function changePage(page) {
            const urlParams = new URLSearchParams(window.location.search);
            urlParams.set('page', page);
            window.location.search = urlParams.toString();
        }

        function changeItemsPerPage(itemsPerPage) {
            const urlParams = new URLSearchParams(window.location.search);
            urlParams.set('items-per-page', itemsPerPage);
            urlParams.set('page', 1); // Reset to the first page
            window.location.search = urlParams.toString();
        }

        function uploadFile(input) {
    const form = input.closest('form');
    const formData = new FormData(form);

    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        // Optionally handle the upload response here
        console.log('Upload successful:', result);
        // You might want to update the image or show a success message
    })
    .catch(error => {
        // Handle any errors
        console.error('Upload error:', error);
    });
}




// Function to open the modal (you can modify this to suit your needs)
function openModal(data) {
    // Populate the form fields with existing data (e.g., fetched from the database)
    document.getElementById('entertainerId').value = data.entertainer_id;
    document.getElementById('firstName').value = data.first_name;
    document.getElementById('lastName').value = data.last_name;
    document.getElementById('title').value = data.title;
    document.getElementById('status').value = data.status;

    // Show the modal
    document.getElementById('editModal').style.display = 'block';
}

// Function to open the modal when the button is clicked
function addEntertainer() {
    document.getElementById("entertainerModal").style.display = "block";
}

// Close both modals
function closeModal(modalId) {
    document.getElementById(modalId).style.display = 'none';
}

// Function to open the edit modal
function viewDetails(id) {
    // Fetch data for the entertainer ID
    fetch(`fetch_entertainer.php?id=${id}`)
        .then(response => response.json())
        .then(data => {
            // Populate the modal with fetched data
            document.getElementById('entertainerId').value = data.entertainer_id;
            document.getElementById('firstName').value = data.first_name;
            document.getElementById('lastName').value = data.last_name;
            document.getElementById('title').value = data.title;
            document.getElementById('status').value = data.status;

            // Show the modal
            document.getElementById('editModal').style.display = 'flex';
        })
        .catch(error => console.error('Error fetching entertainer data:', error));
}




// Function to open the add entertainer modal
function addEntertainer() {
    document.getElementById("entertainerModal").style.display = "block";
}

// Optional: Close the modal if the user clicks anywhere outside of the modal
window.onclick = function(event) {
    if (event.target == document.getElementById("editModal")) {
        closeModal('editModal');
    } else if (event.target == document.getElementById("entertainerModal")) {
        closeModal('entertainerModal');
    }
};

 // Make sure the message element exists before trying to hide it
 const messageElement = document.getElementById('status-message');
        if (messageElement) {
            // Set a timer to hide the message after 3 seconds
            setTimeout(() => {
                messageElement.style.display = 'none'; // Hide the message
            }, 2000); // 3000 milliseconds = 3 seconds
        }

        function searchEntertainer() {
    const searchValue = document.getElementById('search-input').value.toLowerCase();
    const rows = document.querySelectorAll('#schedule-table-body tr');

    rows.forEach(row => {
        const firstName = row.cells[1].textContent.toLowerCase(); // Adjust the index based on your table
        if (firstName.includes(searchValue)) {
            row.style.display = ''; // Show row
        } else {
            row.style.display = 'none'; // Hide row
        }
    });
}
    </script>
</body>
</html>