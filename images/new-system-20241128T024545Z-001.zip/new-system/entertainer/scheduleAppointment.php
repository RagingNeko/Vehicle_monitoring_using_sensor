<?php
session_start();
header('Content-Type: application/json');

// Initialize a session variable to track submission status
if (!isset($_SESSION['submission_status'])) {
    $_SESSION['submission_status'] = false;
}

// Get POST data
$date = $_POST['date'] ?? null;
$start_time = $_POST['start_time'] ?? null;
$end_time = $_POST['end_time'] ?? null; 
$price = $_POST['price'] ?? null;

// Check if required data is provided
if (!$date || !$start_time || !$end_time || !$price) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Date, start time, end time, and price are required']);
    exit;
}

// Sanitize and validate inputs
$date = filter_var($date, FILTER_SANITIZE_STRING);
$start_time = filter_var($start_time, FILTER_SANITIZE_STRING);
$end_time = filter_var($end_time, FILTER_SANITIZE_STRING);
$price = filter_var($price, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);

// Validate date format
$appointmentDate = DateTime::createFromFormat('Y-m-d', $date);
if (!$appointmentDate || $appointmentDate->format('Y-m-d') !== $date) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Invalid date format']);
    exit;
}

// Check if the provided date is in the past
$currentDate = new DateTime();
if ($appointmentDate < $currentDate) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Cannot schedule appointments for past dates']);
    exit;
}

// Retrieve entertainer_id from session
$entertainer_id = $_SESSION['entertainer_id'] ?? null;
if (!$entertainer_id) {
    http_response_code(401); // Unauthorized
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

// Prevent double submission
if ($_SESSION['submission_status']) {
    http_response_code(429); // Too Many Requests
    echo json_encode(['success' => false, 'message' => 'Duplicate submission detected']);
    exit;
}

$_SESSION['submission_status'] = true; // Mark submission as in progress

// Database connection details (consider using environment variables)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_booking_system";

try {
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception('Database connection failed: ' . $conn->connect_error);
    }

    // Check if the appointment already exists
    $stmt = $conn->prepare("SELECT * FROM sched_time WHERE entertainer_id = ? AND date = ? AND start_time = ?");
    $stmt->bind_param("iss", $entertainer_id, $date, $start_time);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        throw new Exception('An appointment for this date and start time already exists');
    }

    // Prepare and execute the SQL query
    $stmt = $conn->prepare("INSERT INTO sched_time (entertainer_id, date, start_time, end_time, price, status) VALUES (?, ?, ?, ?, ?, 'Available')");
    $stmt->bind_param("issss", $entertainer_id, $date, $start_time, $end_time, $price);

    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Appointment scheduled successfully']);
    } else {
        throw new Exception('Failed to schedule appointment');
    }

} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
} finally {
    // Reset submission status
    $_SESSION['submission_status'] = false;

    // Close connection
    if (isset($stmt)) {
        $stmt->close();
    }
    if (isset($conn)) {
        $conn->close();
    }
}
?>
