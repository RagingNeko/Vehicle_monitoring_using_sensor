
<?php

session_start();

// Check if the user is logged in
if (!isset($_SESSION['first_name'])) {
    header("Location: entertainer-loginpage.php"); // Redirect to login page if not logged in
    exit();
}

$first_name = htmlspecialchars($_SESSION['first_name']); // Retrieve and sanitize the first_name
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Dashboard</title>
    <link rel="stylesheet" href="style3.css">
    
    <script src="calendar.js" defer></script>
</head>
<style>
/* General Container Styling */
.container {
    display: flex;
    justify-content: space-between;
    padding: 10px;
    margin-top: 0%;
    gap: 20px; /* Add space between the two panels */
    flex-wrap: wrap; /* Allows the panels to wrap on small screens */
    align-items: flex-start; /* Align items to the top */
}

/* Left and Right Panels */
.left-panel, .right-panel {
    box-sizing: border-box;
}

.left-panel {
    flex: 1 1 60%; /* Flex-grow: 1, Flex-shrink: 1, Base-width: 70% */
    max-width: 60%; /* Set a max width for left panel */
    margin-left: 10px;
}

.right-panel {
    flex: 1 1 20%; /* Flex-grow: 1, Flex-shrink: 1, Base-width: 28% */
    max-width: 20%; /* Set a max width for right panel */
    min-width: 300px; /* Ensure the right panel doesn't shrink below 300px */
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background-color: #f8f9fa;
    margin-right: 10px;
}

/* Calendar Section */
.calendar {
    background-color: #fff;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 5px;
}

.calendar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.calendar-header button {
    padding: 10px;
    background-color: green;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.calendar-header h2 {
    font-size: 24px;
    margin: 0;
    text-align: center;
}

.calendar-grid {
    display: grid;
    grid-template-columns: repeat(7, 1fr); /* 7 columns for each day of the week */
    gap: 10px;
}

.calendar-grid .date-box {
    height: 80px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    border: 1px solid #ddd;
    border-radius: 5px;
    cursor: pointer;
    text-align: center;
}

.calendar-grid .date-box .day-number {
    font-size: 16px;
    margin-bottom: 5px;
}

.calendar-grid .date-box .book-now {
    padding: 5px 10px;
    background-color: green;
    color: white;
    border: none;
    border-radius: 3px;
    cursor: pointer;
    font-size: 12px;
}

/* Appointment Form Section */
.right-panel h2 {
    font-size: 22px;
    text-align: center;
    color: #007bff; /* Blue color for header */
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    font-size: 14px;
}

.form-group input[type="text"],
.form-group input[type="date"] {
    width: 100%;
    padding: 10px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.form-group button {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    cursor: pointer;
}

.form-group button:hover {
    background-color: #0056b3;
}

/* Media Query for Mobile Devices */
@media (max-width: 768px) {
    .container {
        flex-direction: column; /* Stack the panels vertically */
    }

    .left-panel, .right-panel {
        width: 100%; /* Panels take up the full width on mobile */
        max-width: 100%; /* Override the max-width to 100% */
        margin-bottom: 20px; /* Add spacing between panels */
    }

    .right-panel {
        min-width: 300px; /* Prevent right panel from shrinking below 300px */
    }

    .calendar-grid {
        grid-template-columns: repeat(7, 1fr); /* 2 columns for smaller screens */
    }
}

.nav-items {
            display: flex;
            gap: 30px; /* Space between items */
            margin-right: 80px; /* Adjust this value to increase space from the profile image */
        }

        .nav-items a {
            text-decoration: none;
            color: white; /* Adjust color as needed */
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .nav-items a:hover {
            background-color: #87CEFA; /* Light blue background on hover */
            text-decoration: none; /* Ensure no underline on hover */
            color: black;
        }

        .dropbtn {
            background: none; /* Remove default button background */
            border: none; /* Remove default button border */
            cursor: pointer; /* Pointer cursor on hover */
        }

        .dropbtn img {
            width: 40px; /* Adjust image size */
            height: auto; /* Maintain aspect ratio */
        }

        .navbar-brand img {
                    width: 40px; /* Adjust size as needed */
                    height: 40px; /* Adjust size as needed */
                    border-radius: 40%; /* Make the image circular */
                }

</style>
<body>
    <header>
    <a class="navbar-brand" href="#">
            <img src="../images/logo.jpg" alt="Brand Logo"> <!-- Update the path to your image -->
        </a>
        <nav>
        <div class="nav-items">
                <a href="entertainer-dashboard.php">Dashboard</a>
                <a href="entertainer-mysched.php">View Schedule</a>
                <a href="entertainer-myAppointment.php">My Appointment</a>
            </div>
        <div class="dropdown" id="dropdown">
                <button class="dropbtn" onclick="toggleDropdown()">
                    <img src="../images/sample.jpg" alt="Profile"> <!-- Replace with your image -->
                </button>
                <div class="dropdown-content" id="dropdown-content">
                    <a href="entertainer-profile.php">View Profile</a>
                    <a href="logout.php">Logout</a> <!-- Logout link pointing to logout.php -->
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="welcome-message">
            <h1>Welcome, <?php echo $first_name; ?>!</h1>
            <p>We’re glad to have you here. Let’s get started!</p>
        </section>
    </main>

    <div class="container">
        <!-- Left Panel (Calendar) -->
        <div class="left-panel">
            <div class="calendar">
                <div class="calendar-header">
                    <button id="prevMonth">&lt;</button>
                    <h2 id="monthYear">September 2024</h2>
                    <button id="nextMonth">&gt;</button>
                </div>
                <div class="calendar-grid" id="calendarGrid">
                    <!-- Days will be populated here by JavaScript -->
                </div>
            </div>
        </div>

<!-- Right Panel (Appointment Form) -->
<form id="appointmentForm" method="POST" action="scheduleAppointment.php.php">
    <div class="right-panel" style="width: 20%;">
        <h2>Schedule Appointment</h2>
        <div class="form-group">
            <label for="date">Date Schedule</label>
            <input type="date" id="date" name="date" required aria-label="Select date for appointment">
        </div>
        <div class="form-group">
            <label for="start_time">Start Time</label>
            <input type="time" id="start_time" name="start_time" required aria-label="Enter start time">
        </div>
        <div class="form-group">
            <label for="end_time">End Time</label>
            <input type="time" id="end_time" name="end_time" required aria-label="Enter end time">
        </div>
        <div class="form-group">
            <label for="price">Hourly Price (₱)</label>
            <input type="text" id="price" name="price" placeholder="0.00" required aria-label="Enter hourly price" pattern="^\d+(\.\d{1,2})?$">
        </div>
        <div class="form-group">
            <button type="submit" id="scheduleButton">Schedule</button>
        </div>
    </div>
</form>



    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown');
            const dropdownContent = document.getElementById('dropdown-content');

            // Toggle the visibility of the dropdown content
            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            } else {
                // Close any other open dropdowns
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });

                dropdown.classList.add('show');
            }
        }

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn') && !event.target.matches('.dropbtn img')) {
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });
            }
        }
    </script>
</body>
</html>
