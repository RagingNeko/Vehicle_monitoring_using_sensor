<?php

session_start();

// Check if the user is logged in
if (!isset($_SESSION['first_name'])) {
    header("Location: entertainer-loginpage.php"); // Redirect to login page if not logged in
    exit();
}

if (isset($_SESSION['entertainer_id'])) {
    $entertainer_id = $_SESSION['entertainer_id'];
} else {
    die("User not logged in.");
}

$first_name = htmlspecialchars($_SESSION['first_name']); // Retrieve and sanitize the first_name

// Database connection
$servername = "localhost"; // Your database server name
$username = "root";        // Your database username
$password = "";            // Your database password
$dbname = "db_booking_system"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Prepare the SQL statement
$stmt = $conn->prepare("SELECT sched_id, date, start_time, end_time, status, price, status FROM sched_time WHERE entertainer_id = ?");
if ($stmt) {
    $stmt->bind_param("i", $entertainer_id);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    echo "Error preparing statement: " . $conn->error;
}

// Check if the statement was prepared correctly
if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

// Assuming the 'entertainer_id' is stored in session
$entertainer_id = $_SESSION['entertainer_id']; // Make sure to set this in your session upon login
$stmt->bind_param("i", $entertainer_id); // Assuming entertainer_id is an integer

// Execute the statement
$stmt->execute();

// Get the result
$result = $stmt->get_result();

// Check if the query was successful
if ($result === false) {
    die("Error executing query: " . $stmt->error); // Display error if query fails
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Dashboard</title>
    <link rel="stylesheet" href="style3.css">
    <link rel="stylesheet" href="calendarstyle.css">
</head>
<style>
         body {
            overflow: auto; /* Only show scrollbar when necessary */
        }

        .content {
            overflow: hidden; /* Hide scrollbar initially */
        }

        /* Show scrollbar when content overflows */
        .content::-webkit-scrollbar {
            width: 0;
            height: 0;
        }

        .content {
            overflow-y: auto;
        }

            /* Schedule List Styles */
        .content {
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: flex-start; /* Align items at the top */
            margin-left: 100px;
            padding: 20px;
            padding-top: 10px; /* Give some space below the header */
            background-color: #f2f2f2;
            min-height: 100vh;
        }

        .schedule-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 100%; /* Ensure it takes full width of the parent */
            max-width: 1200px; /* Set a maximum width for larger screens */
        }


        .schedule-container input[type="text"] {
            padding: 10px;
            width: 40%;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .schedule-header {
            background-color: #fff;
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 10px 10px 0 0;
        }

        .schedule-header h2 {
            margin: 0;
            font-size: 18px;
            color: #333;
        }

        .schedule-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .schedule-table th, .schedule-table td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
            color: #333;
        }

        .schedule-table th {
            background-color: #f8f8f8;
            font-weight: normal;
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .pagination select {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .pagination span {
            color: #888;
        }

        .pagination-controls {
            display: flex;
            gap: 5px;
        }

        .pagination-controls img {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .header {
                width: 100%;
                left: 0;
            }

            .content {
                margin-left: 0;
                padding-top: 60px; /* Adjust padding for smaller screens */
                padding: 10px; /* Add padding to the content */
            }

            .schedule-container {
                width: 100%; /* Full width for small screens */
                padding: 10px; /* Adjust padding */
            }

            .schedule-header input[type="text"] {
                width: 100%; /* Full width input for smaller screens */
            }

            .pagination {
                flex-direction: row; /* Stack pagination controls vertically */
                align-items: flex-start;
            }

            .pagination-controls {
                width: 100%;
                justify-content: space-between; /* Space out controls */
            }
        }


        .button-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .schedule-header .refresh-btn
         {
            width: 40px;
            height: 40px;
            border: none;
            background-color: white;
            color: black;
            font-size: 18px;
            border-radius: 50%;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .schedule-header .refresh-btn:hover
        {
            background-color: #f0fff0;
        }

        #status-select {
            padding: 10px;
            width: 30%;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 20px; /* Space between dropdown and table */
        }

        .nav-items {
            display: flex;
            gap: 30px; /* Space between items */
            margin-right: 80px; /* Adjust this value to increase space from the profile image */
        }

        .nav-items a {
            text-decoration: none;
            color: white; /* Adjust color as needed */
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .nav-items a:hover {
            background-color: #87CEFA; /* Light blue background on hover */
            text-decoration: none; /* Ensure no underline on hover */
            color: black;
        }

        .dropbtn {
            background: none; /* Remove default button background */
            border: none; /* Remove default button border */
            cursor: pointer; /* Pointer cursor on hover */
        }

        .dropbtn img {
            width: 40px; /* Adjust image size */
            height: auto; /* Maintain aspect ratio */
        }

        .navbar-brand img {
                    width: 40px; /* Adjust size as needed */
                    height: 40px; /* Adjust size as needed */
                    border-radius: 40%; /* Make the image circular */
                }

                .button-group {
    display: flex;
    gap: 5px; /* Adjust this value for the desired spacing */
}

.button-group button {
    padding: 5px 10px; /* Add some padding for better appearance */
    cursor: pointer; /* Change cursor on hover */
}

.edit-btn {
    background-color: blue; /* Blue background */
    color: white; /* White text */
    border: none; /* Remove default border */
    padding: 5px 10px; /* Padding */
    border-radius: 4px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    transition: background-color 0.3s; /* Transition for hover effect */
}

.edit-btn:hover {
    background-color: darkblue; /* Darker blue on hover */
}

.delete-btn {
    background-color: red; /* Red background */
    color: white; /* White text */
    border: none; /* Remove default border */
    padding: 5px 10px; /* Padding */
    border-radius: 4px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    transition: background-color 0.3s; /* Transition for hover effect */
}

.delete-btn:hover {
    background-color: darkred; /* Darker red on hover */
}

/* Modal styles */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1000; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0, 0, 0, 0.4); /* Black w/ opacity */
}

.modal-content {
    background-color: #fefefe;
    margin: auto; /* Center the modal */
    padding: 20px;
    border: 1px solid #888;
    width: 500px; /* Fixed width for modal content */
    border-radius: 10px; /* Rounded corners */
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); /* Shadow for depth */
    margin-top: 10%;
}

.modal-content label {
    display: block;
    margin-bottom: 5px; /* Space between label and input */
}

.modal-content input[type="text"],
.modal-content input[type="date"],
.modal-content input[type="time"] {
    width: calc(100% - 20px); /* Full width minus padding */
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    margin-bottom: 15px; /* Space between each input field */
}

.modal-content button[type="submit"] {
    background-color: #4CAF50; /* Green background */
    color: white; /* White text */
    border: none; /* Remove default border */
    padding: 10px; /* Padding */
    border-radius: 4px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    transition: background-color 0.3s; /* Transition for hover effect */
}

.modal-content button[type="submit"]:hover {
    background-color: #45a049; /* Darker green on hover */
}

.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}

</style>
<body>
    <header>
    <a class="navbar-brand" href="#">
            <img src="../images/logo.jpg" alt="Brand Logo"> <!-- Update the path to your image -->
        </a>
        <nav>
        <div class="nav-items">
                <a href="entertainer-dashboard.php">Set a Schedule</a>
                <a href="entertainer-mysched.php">View Schedule</a>
                <a href="entertainer-myAppointment.php">My Appointment</a>
            </div>
            <div class="dropdown" id="dropdown">
                <button class="dropbtn" onclick="toggleDropdown()">
                    <img src="../images/sample.jpg" alt="Profile"> <!-- Replace with your image -->
                </button>
                <div class="dropdown-content" id="dropdown-content">
                    <a href="entertainer-profile.php">View Profile</a>
                    <a href="logout.php">Logout</a> <!-- Logout link pointing to logout.php -->
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="welcome-message">
            <h1>Welcome, <?php echo $first_name; ?>!</h1>
            <p>We’re glad to have you here. Let’s get started!</p>
        </section>
    </main>

    <div class="content">
        <div class="schedule-container">
            <h2>Schedule List</h2>
            <div class="schedule-header">
                <select id="status-select">
                    <option value="">Select Status</option>
                    <option value="Unavailable">Unavailable</option>
                    <option value="Available">Available</option>
                    <!-- Add more status options as needed -->
                </select>
                <div class="button-group">
                    <button class="refresh-btn" aria-label="Refresh">⟳</button>
                </div>
            </div>
            <table class="schedule-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Status</th>
                        <th>Price</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="schedule-table-body">
                    <?php
                        if ($result->num_rows > 0) {
                            // Loop through the results and display each row
                            while($row = $result->fetch_assoc()) {
                                // Format start time and end time to 12-hour format with AM/PM
                                $start_time = date("g:i A", strtotime($row['start_time']));
                                $end_time = date("g:i A", strtotime($row['end_time']));
                            
                                echo "<tr data-sched_id='" . htmlspecialchars($row['sched_id']) . "' data-status='" . htmlspecialchars($row['status']) . "'>";
                                echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                                echo "<td>" . htmlspecialchars($start_time) . "</td>";
                                echo "<td>" . htmlspecialchars($end_time) . "</td>";
                                echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                                echo "<td>" . htmlspecialchars($row['price']) . "</td>";
                                echo "<td>
                                        <button class='edit-btn'>Edit</button>
                                        <button class='delete-btn'>Delete</button>
                                      </td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='6' class='no-schedule'>No schedules available</td></tr>";
                        }
                    ?>
                </tbody>
            </table>
            <div class="pagination">
                <div>
                    <label for="items-per-page">Items per page:</label>
                    <select id="items-per-page">
                        <option value="10">10</option>
                        <option value="20">20</option>
                        <option value="30">30</option>
                    </select>
                </div>
                <div class="page-controls">
                    <button disabled aria-label="Previous Page">◀</button>
                    <span id="pagination-info">0-0 of 0</span>
                    <button disabled aria-label="Next Page">▶</button>
                </div>
            </div>
        </div>
    </div>

    <div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2>Edit Schedule</h2>
        <form id="editForm">
            <input type="hidden" id="scheduleId" value="">
            <label for="editDate">Date:</label>
            <input type="date" id="editDate" required>
            <br>
            <label for="editStartTime">Start Time:</label>
            <input type="time" id="editStartTime" required>
            <br>
            <label for="editEndTime">End Time:</label>
            <input type="time" id="editEndTime" required>
            <br>
            <label for="editPrice">Price:</label>
            <input type="text" id="editPrice" required>
            <br>
            <button type="submit">Update Schedule</button>
        </form>
    </div>
</div>

    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown');
            const dropdownContent = document.getElementById('dropdown-content');

            // Toggle the visibility of the dropdown content
            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            } else {
                // Close any other open dropdowns
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });

                dropdown.classList.add('show');
            }
        }

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn') && !event.target.matches('.dropbtn img')) {
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });
            }
        }

        // JavaScript to handle the modal
    const modal = document.getElementById("editModal");
    const span = document.getElementsByClassName("close")[0];

    // Add event listeners to all edit buttons
    document.querySelectorAll('.edit-btn').forEach(button => {
        button.addEventListener('click', function() {
            // Get the row data to edit
            const row = this.closest('tr');
            const scheduleId = row.dataset.sched_id;
            const date = row.cells[0].innerText;
            const startTime = row.cells[1].innerText;
            const endTime = row.cells[2].innerText;
            const price = row.cells[3].innerText;
            
            // Set the values in the modal fields
            document.getElementById('editDate').value = date;
            document.getElementById('editStartTime').value = startTime;
            document.getElementById('editEndTime').value = endTime;
            document.getElementById('editPrice').value = price;
            // Placeholder for schedule ID
            document.getElementById('scheduleId').value = row.dataset.sched_id; // Assume you add data-id in your original row

            // Display the modal
            modal.style.display = "block";
        });
    });

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

   // Handle the form submission (for demonstration)
document.getElementById('editForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const scheduleId = document.getElementById('scheduleId').value;
    const date = document.getElementById('editDate').value;
    const startTime = document.getElementById('editStartTime').value;
    const endTime = document.getElementById('editEndTime').value;
    const price = document.getElementById('editPrice').value;

    // Prepare data to send
    const data = {
        scheduleId: scheduleId,
        date: date,
        startTime: startTime,
        endTime: endTime,
        price: price
    };

    // Send AJAX request to update_schedule.php
    fetch('update_schedule.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Schedule updated successfully!');
            modal.style.display = "none"; // Close the modal after submission
            location.reload(); // Reload the page to see changes
        } else {
            alert('Error updating schedule: ' + data.error);
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });
});

// Add event listeners to all delete buttons
document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', function() {
        const row = this.closest('tr');
        const scheduleId = row.dataset.sched_id;

        if (confirm('Are you sure you want to delete this schedule?')) {
            // Send an AJAX request to delete_schedule.php
            fetch('delete_schedule.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ scheduleId: scheduleId }),
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Schedule deleted successfully!');
                    // Remove the row from the table
                    row.remove();
                } else {
                    alert('Error deleting schedule: ' + data.error);
                }
            })
            .catch((error) => {
                console.error('Error:', error);
            });
        }
    });
});

// Add event listener for the status dropdown
document.getElementById('status-select').addEventListener('change', function() {
    const selectedStatus = this.value.toLowerCase();
    
    // Get all rows in the schedule table
    const rows = document.querySelectorAll('#schedule-table-body tr');

    // Loop through rows and hide/show based on selected status
    rows.forEach(row => {
        const status = row.dataset.status.toLowerCase();
        if (selectedStatus === '' || status === selectedStatus) {
            row.style.display = ''; // Show row
        } else {
            row.style.display = 'none'; // Hide row
        }
    });
});

document.addEventListener("DOMContentLoaded", function() {
    const scheduleBody = document.getElementById('schedule-table-body');
    const message = document.getElementById('no-schedules-message');

    // Check if there are no rows after rendering
    if (scheduleBody.rows.length === 0) {
        message.style.display = 'block';  // Show the message if no rows
    } else {
        message.style.display = 'none';   // Hide the message if there are rows
    }
});
    </script>
</body>
</html>
