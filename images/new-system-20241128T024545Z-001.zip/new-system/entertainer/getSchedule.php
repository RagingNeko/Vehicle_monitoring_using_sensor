<?php
session_start();
header('Content-Type: application/json');

// Database connection details
$host = 'localhost';
$db = 'db_booking_system';
$user = 'root';
$pass = '';

// Create a new PDO instance
$pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Retrieve month, year, and entertainer_id
$month = $_GET['month'];
$year = $_GET['year'];
$entertainer_id = $_SESSION['entertainer_id'] ?? null;

if (!$entertainer_id) {
    echo json_encode(['success' => false, 'message' => 'User not authenticated']);
    exit;
}

// Prepare and execute the SQL query
$sql = "SELECT * FROM sched_time WHERE MONTH(date) = :month AND YEAR(date) = :year AND entertainer_id = :entertainer_id";
$stmt = $pdo->prepare($sql);
$stmt->execute([
    'month' => $month,
    'year' => $year,
    'entertainer_id' => $entertainer_id
]);

$schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($schedule);
?>
