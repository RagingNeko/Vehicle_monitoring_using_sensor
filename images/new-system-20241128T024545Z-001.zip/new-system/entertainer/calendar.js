const calendarGrid = document.getElementById('calendarGrid');
const monthYear = document.getElementById('monthYear');
const prevMonth = document.getElementById('prevMonth');
const nextMonth = document.getElementById('nextMonth');

let currentDate = new Date();
const today = new Date(); // Today's date to compare with

async function fetchSchedule(month, year) {
    try {
        const response = await fetch(`getSchedule.php?month=${month}&year=${year}`);
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching schedule:', error);
    }
}

async function generateCalendar(date) {
    const month = date.getMonth() + 1;
    const year = date.getFullYear();
    const schedule = await fetchSchedule(month, year);

    calendarGrid.innerHTML = '';
    const firstDay = new Date(year, month - 1, 1).getDay();
    const daysInMonth = new Date(year, month, 0).getDate();
    const today = new Date(); // Current date to disable past dates
    today.setHours(0, 0, 0, 0); // Set to start of the day for comparison

    monthYear.textContent = date.toLocaleString('default', { month: 'long', year: 'numeric' });

    // Create empty slots for days of the week before the 1st of the month
    for (let i = 0; i < firstDay; i++) {
        const emptyDiv = document.createElement('div');
        calendarGrid.appendChild(emptyDiv);
    }

    // Loop through all days in the month
    for (let day = 1; day <= daysInMonth; day++) {
        const dayDiv = document.createElement('div');
        dayDiv.classList.add('date-box');

        const dayNumber = document.createElement('div');
        dayNumber.classList.add('day-number');
        dayNumber.textContent = day;

        const bookButton = document.createElement('button');
        bookButton.textContent = 'Book now';
        bookButton.classList.add('book-now');

        const currentDay = new Date(year, month - 1, day);
        const isDateInSchedule = schedule.find(entry => new Date(entry.date).toDateString() === currentDay.toDateString());

        // Disable previous dates
        if (currentDay < today) {
            bookButton.disabled = true;
            dayDiv.classList.add('disabled');
        } else if (isDateInSchedule) {
            // Handle based on schedule status
            if (isDateInSchedule.status === 'Available') {
                // Date is available to book
                dayDiv.classList.add('available');
            } else if (isDateInSchedule.status === 'Booked') {
                // Date is booked
                bookButton.disabled = true;
                dayDiv.classList.add('booked');
            } else {
                // Other statuses (if any)
                bookButton.disabled = true;
                dayDiv.classList.add('disabled');
            }
        } else {
            // Date is not in the database
            bookButton.disabled = true;
            dayDiv.classList.add('disabled');
        }

        // Append elements to the day box
        dayDiv.appendChild(dayNumber);
        if (!bookButton.disabled) {
            dayDiv.appendChild(bookButton);
        }
        calendarGrid.appendChild(dayDiv);
    }
}


prevMonth.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() - 1);
    generateCalendar(currentDate);
});

nextMonth.addEventListener('click', () => {
    currentDate.setMonth(currentDate.getMonth() + 1);
    generateCalendar(currentDate);
});

generateCalendar(currentDate);


document.getElementById('scheduleButton').addEventListener('click', async () => {
    const button = document.getElementById('scheduleButton');
    button.disabled = true;
    button.textContent = 'Submitting...';

    const date = document.getElementById('date').value;
    const start_time = document.getElementById('start_time').value;
    const end_time = document.getElementById('end_time').value;
    const price = document.getElementById('price').value;

    if (!date || !start_time || !end_time || !price) {
        alert('Please fill out all fields.');
        button.disabled = false;
        button.textContent = 'Schedule';
        return;
    }

    try {
        const response = await fetch('scheduleAppointment.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({
                date: date,
                start_time: start_time,
                end_time: end_time,
                price: price
            })
        });

        const result = await response.json();

        if (result.success) {
            alert('Appointment scheduled successfully!');
            generateCalendar(currentDate); // Refresh calendar
        } else {
            alert(`Failed to schedule appointment: ${result.message}`);
        }
    } catch (error) {
        console.error('Error scheduling appointment:', error);
        alert('An error occurred while scheduling the appointment.');
    } finally {
        button.disabled = false;
        button.textContent = 'Schedule';
    }
});

