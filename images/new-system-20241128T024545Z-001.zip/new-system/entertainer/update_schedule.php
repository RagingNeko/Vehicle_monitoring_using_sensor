<?php
session_start();
if (!isset($_SESSION['entertainer_id'])) {
    die(json_encode(['success' => false, 'error' => 'User not authenticated.']));
}

$entertainer_id = $_SESSION['entertainer_id'];
$conn = new mysqli("localhost", "root", "", "db_booking_system");

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'error' => 'Connection failed: ' . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and validate inputs
    $data = json_decode(file_get_contents("php://input"), true);
    $scheduleId = $data['scheduleId'] ?? null;
    $date = $data['date'] ?? null;
    $startTime = $data['startTime'] ?? null;
    $endTime = $data['endTime'] ?? null;
    $status = $data['status'] ?? null;
    $price = $data['price'] ?? null;

    if (!$scheduleId || !$date || !$startTime || !$endTime || !$status || !$price) {
        echo json_encode(['success' => false, 'error' => 'Invalid input.']);
        exit;
    }

    // Prepare SQL statement
    $stmt = $conn->prepare("UPDATE sched_time SET date=?, start_time=?, end_time=?, status=?, price=? WHERE sched_id=? AND entertainer_id=?");
    
    if (!$stmt) {
        die(json_encode(['success' => false, 'error' => $conn->error]));
    }

    $stmt->bind_param("ssssdii", $date, $startTime, $endTime, $status, $price, $scheduleId, $entertainer_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $stmt->error]);
    }

    $stmt->close();
}

$conn->close();
?>