-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2024 at 03:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_booking_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `first_name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_account`
--

INSERT INTO `admin_account` (`admin_id`, `username`, `password`, `first_name`) VALUES
(1, 'admin', '1234', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `booking_report`
--

CREATE TABLE `booking_report` (
  `book_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `entertainer_id` int(11) DEFAULT NULL,
  `sched_id` int(11) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `street` varchar(255) DEFAULT NULL,
  `barangay` varchar(100) DEFAULT NULL,
  `municipality` varchar(100) DEFAULT NULL,
  `province` varchar(100) DEFAULT NULL,
  `date_schedule` date DEFAULT NULL,
  `time_start` time DEFAULT NULL,
  `time_end` time DEFAULT NULL,
  `price_offer` decimal(10,2) DEFAULT NULL,
  `entertainer_name` varchar(255) DEFAULT NULL,
  `entertainer_wage` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','accepted','declined') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `booking_report`
--

INSERT INTO `booking_report` (`book_id`, `customer_id`, `entertainer_id`, `sched_id`, `customer_name`, `contact_number`, `email`, `street`, `barangay`, `municipality`, `province`, `date_schedule`, `time_start`, `time_end`, `price_offer`, `entertainer_name`, `entertainer_wage`, `status`) VALUES
(10, NULL, 1, NULL, 'customer1', '09123345567', '', 'purok 1', 'culo', 'molave', 'zamboanga del sur', '2024-09-29', '15:48:00', '17:48:00', 7000.00, '0', NULL, NULL),
(11, 1, 1, NULL, 'customer1', '091234567890', 'omandamshaira@gmail.com', 'purok6', 'culo', 'molave', 'zamboanga del sur', '2024-10-21', '01:10:00', '00:00:04', 10000.00, NULL, NULL, 'pending'),
(12, 1, 1, NULL, 'customer1', '091234567890', 'omandamshaira@gmail.com', 'purok6', 'culo', 'molave', 'zamboanga del sur', '2024-10-21', '01:10:00', '04:10:00', 10000.00, NULL, NULL, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `customer_account`
--

CREATE TABLE `customer_account` (
  `customer_id` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `sex` enum('male','female') NOT NULL,
  `birthdate` date NOT NULL,
  `age` int(11) NOT NULL,
  `building` varchar(50) DEFAULT NULL,
  `street` varchar(100) NOT NULL,
  `barangay` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `agreed_to_terms` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_account`
--

INSERT INTO `customer_account` (`customer_id`, `first_name`, `last_name`, `sex`, `birthdate`, `age`, `building`, `street`, `barangay`, `city`, `province`, `email`, `username`, `password`, `agreed_to_terms`, `created_at`) VALUES
(1, 'customer', 'customer', 'male', '2014-09-30', 0, NULL, '', '', '', '', '', 'customer', '123', 0, '2024-09-06 01:52:49'),
(3, 'customer2', 'customer2', 'male', '2014-09-24', 0, NULL, '', '', '', '', 'test@gmail.com', 'customer2', '123', 0, '2024-09-06 01:56:20');

-- --------------------------------------------------------

--
-- Table structure for table `entertainer_account`
--

CREATE TABLE `entertainer_account` (
  `entertainer_id` int(11) NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(20) NOT NULL,
  `first_name` varchar(20) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `title` varchar(50) NOT NULL,
  `status` enum('Active','Inactive') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `entertainer_account`
--

INSERT INTO `entertainer_account` (`entertainer_id`, `profile_image`, `username`, `password`, `first_name`, `last_name`, `title`, `status`) VALUES
(1, 'sample.jpg', 'entertainer', '123', 'entertainer1', 'entertainer1', 'The Mighty Band', 'Active'),
(2, 'sample.jpg', 'entertainer2', '123', 'entertainer2', 'entertainer2', 'The Singerist', 'Active'),
(3, 'sample.jpg', 'entertainer3', '123', 'entertainer3', 'entertainer3', 'The Bugeyman', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `sched_time`
--

CREATE TABLE `sched_time` (
  `sched_id` int(11) NOT NULL,
  `entertainer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `status` enum('Available','Booked','Unavailable') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sched_time`
--

INSERT INTO `sched_time` (`sched_id`, `entertainer_id`, `date`, `price`, `status`) VALUES
(20, 2, '2024-09-21', 1000.00, 'Available'),
(29, 1, '2024-09-24', 500.00, 'Available'),
(30, 1, '2024-09-20', 1000.00, 'Available'),
(31, 1, '2024-09-21', 1000.00, 'Available'),
(32, 1, '2024-09-29', 1000.00, 'Available'),
(33, 1, '2024-10-09', 1000.00, 'Available'),
(34, 1, '2024-10-10', 1000.00, 'Available'),
(35, 1, '2024-10-11', 1000.00, 'Available'),
(36, 1, '2024-10-12', 1000.00, 'Available'),
(38, 1, '2024-10-21', 1000.00, 'Available'),
(39, 1, '2024-10-23', 1000.00, 'Available'),
(40, 1, '2024-10-24', 1000.00, 'Available'),
(51, 1, '2024-10-25', 1000.00, 'Available'),
(60, 1, '2024-10-26', 1000.00, 'Available');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `booking_report`
--
ALTER TABLE `booking_report`
  ADD PRIMARY KEY (`book_id`),
  ADD KEY `fk_customer` (`customer_id`),
  ADD KEY `fk_entertainer` (`entertainer_id`),
  ADD KEY `sched_id` (`sched_id`);

--
-- Indexes for table `customer_account`
--
ALTER TABLE `customer_account`
  ADD PRIMARY KEY (`customer_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `entertainer_account`
--
ALTER TABLE `entertainer_account`
  ADD PRIMARY KEY (`entertainer_id`);

--
-- Indexes for table `sched_time`
--
ALTER TABLE `sched_time`
  ADD PRIMARY KEY (`sched_id`),
  ADD UNIQUE KEY `unique_schedule` (`entertainer_id`,`date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_account`
--
ALTER TABLE `admin_account`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `booking_report`
--
ALTER TABLE `booking_report`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer_account`
--
ALTER TABLE `customer_account`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `entertainer_account`
--
ALTER TABLE `entertainer_account`
  MODIFY `entertainer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sched_time`
--
ALTER TABLE `sched_time`
  MODIFY `sched_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking_report`
--
ALTER TABLE `booking_report`
  ADD CONSTRAINT `fk_customer` FOREIGN KEY (`customer_id`) REFERENCES `customer_account` (`customer_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_entertainer` FOREIGN KEY (`entertainer_id`) REFERENCES `entertainer_account` (`entertainer_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
