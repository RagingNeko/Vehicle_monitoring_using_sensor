<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Landing Page</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            color: #333;
            position: relative; /* Ensure that the background-blur div is positioned correctly */
        }
        .background-blur {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('assets/img/bg.jpg'); /* Path to your background image */
            background-size: cover;
            background-position: center;
            filter: blur(5px); /* Adjust the blur amount as needed */
            z-index: -1; /* Ensure it is behind the content */
            /* Optional: Add an overlay to darken the background if needed */
            background-color: rgba(0, 0, 0, 0.5);
        }

        /* Add this new style */
.navbar-fixed {
    position: fixed; /* Fix the navbar at the top of the viewport */
    top: 0;
    width: 100%; /* Make sure the navbar spans the full width */
    z-index: 1030; /* Ensure it stays on top of other content */
}

        .navbar {
            background-color: #003366;
            border-bottom: 2px solid #003366; /* Optional border to enhance separation */
        }

        .navbar .nav-link {
            color: white; /* Text color */
            padding: 0.5rem 1rem; /* Add padding to ensure spacing around the text */
            transition: color 0.3s; /* Smooth transition for text color */
        }

        .navbar .nav-link:hover {
            color: #5A9BD4; /* Change text color on hover */
        }

        .navbar .nav-link.btn {
            background-color: transparent; /* Remove background color */
            color: white; /* Set text color to white */
            border: none; /* Remove border */
        }

        .navbar .nav-link.btn:hover {
            color: #5A9BD4; /* Change text color on hover */
        }

        .nav-item:not(:last-child) {
            margin-right: 7rem; /* Adjust this value to increase/decrease the spacing */
        }

        .container {
            position: relative; /* Ensure the content is positioned above the background-blur */
            width: 85%;
            margin: auto;
            overflow: hidden; /* Ensure that the container does not create extra scrollbars */
        }
        .hero {
            background: url('hero-image.jpg') no-repeat center center/cover;
            color: #fff;
            padding: 5em 0;
            text-align: center;
            position: relative;
            z-index: 1;
        }
        .hero::after {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: -1;
        }
        .hero h1 {
            font-size: 3em;
            margin: 0;
            animation: fadeIn 2s ease-in-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        section {
            padding: 4em 2em;
        }
        section#who-we-are {
            margin-top: 60px;
            background-color: #e0f7fa;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: relative;
            padding: 2em;
        }
        .text-content {
            max-width: 60%;
        }
        .image-rectangle {
            width: 330px;
            height: auto;
            position: absolute;
            right: 2em;
            top: 40%;
            transform: translateY(-50%);
            animation: slideDown 1.5s ease-out;
        }
        @keyframes slideDown {
            from {
                transform: translateY(-150%);
                opacity: 0;
            }
            to {
                transform: translateY(auto);
                opacity: 1;
            }
        }
        section#services {
            background-color: #f1f8e9;
        }
        section#team {
            background-color: #FFE4E1;
            padding: 4em 2em;
        }
        section#values {
            background-color: #F5FFFA;
        }
        section#why-choose-us {
            background-color: #e8eaf6;
        }
        section.contact {
            background-color: #333;
            color: #fff;
        }
        h2 {
            color: #333;
            font-size: 2.5em;
            border-bottom: 2px solid #333;
            padding-bottom: 0.5em;
            margin-bottom: 1em;
            transition: color 0.3s;
            animation: fadeIn 2s ease-in-out;
        }

        @keyframes slideRight {
            from { 
                transform: translateX(-100%);
                opacity: 0;
            }
            to { 
                transform: translateX(0);
                opacity: 1;
            }
        }
        p {
            margin-bottom: 1em;
            line-height: 1.8;
            animation: slideRight 1.5s ease-out;
            text-align: justify;
        }
        .services ul {
            list-style: none;
            padding: 0;
            display: flex;
            flex-wrap: wrap;
            gap: 1em;
        }
        .services li {
            background: #fff;
            border: 1px solid #ddd;
            padding: 1em;
            border-radius: 10px;
            transition: transform 0.3s, box-shadow 0.3s;
            flex: 1 1 calc(33.333% - 1em);
        }
        .services li:hover {
            transform: translateY(-10px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .team {
            display: flex;
            flex-wrap: wrap;
            gap: 1.5em;
            justify-content: space-between;
        }
        .team-member {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 1em;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            flex: 1 1 calc(25% - 1.5em); /* Ensure 4 members fit in a row */
            box-sizing: border-box;
            text-align: center;
            /* Set height to make it rectangular */
            height: 350px; /* Adjust height as needed */
            max-width: 220px; /* Adjust max width to maintain rectangle proportion */
            margin: 0 auto; /* Center align each team member */
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .team-member-image {
            width: 100%;
            height: 200px; /* Adjust height for image to fit */
            background-color: #f0f0f0;
            border-radius: 10px;
            margin-bottom: 0.5em;
            margin-top: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .team-member-image img {
            margin-bottom: 60px;
            max-width: 100%;
            max-height: 130%;
            object-fit: cover;
            border-radius: 10px; /* Optional: Matches the container's border-radius */
        }
        .team-member-info {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .team-member-info h3 {
            margin: 0.2em 0;
            font-size: 1.1em; /* Adjust font size for compact look */
            color: #333;
        }
        .team-member-info p {
            text-align: center;
            font-size: 0.9em; /* Adjust font size for compact look */
            color: #555;
        }

        .team-member:hover {
            transform: translateY(-10px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .contact a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
            border-bottom: 2px solid #fff;
            transition: color 0.3s, border-bottom 0.3s;
        }
        .contact a:hover {
            color: #007BFF;
            border-bottom: 2px solid #007BFF;
        }
        footer {
            background: #222;
            color: #fff;
            text-align: center;
            padding: 1em 0;
            font-size: 0.9em;
        }
    </style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-fixed">
    <a class="navbar-brand" href="#">Brand</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn" href="signuppage.php">Signup</a>
            </li>
        </ul>
    </div>
</nav>


    <!-- New content starts here -->
    <div class="background-blur"></div>
    <div class="container">

        <section id="who-we-are" class="hero">
            <div class="text-content">
                <h2>About Us</h2>
                <p>We are a passionate team dedicated to delivering exceptional [services/products]. With years of experience and a commitment to excellence, we strive to exceed expectations in every project we undertake.</p>
            </div>
            <img src="assets/img/sample1.jpg" alt="About Us Image" class="image-rectangle">
        </section>

        <section id="services" class="services">
            <h2>What We Do</h2>
            <ul>
                <li><strong>Live Performances:</strong> From high-energy concerts to intimate acoustic sets, our performances are tailored to captivate and engage. We specialize in [mention genres or types of performances, e.g., "rock, jazz, and custom event entertainment"].</li>
                <li><strong>Event Production:</strong> We handle every detail of your event, ensuring a seamless and memorable experience. Our services range from [list key services, e.g., "event planning and coordination to sound and lighting design"].</li>
                <li><strong>Customized Entertainment:</strong> We offer bespoke entertainment solutions designed to fit your specific needs and preferences. Whether it’s a corporate gala, a private party, or a themed event, we bring your vision to life.</li>
            </ul>
        </section>

        <section id="team">
            <h2>Meet Our Team</h2>
            <div class="team">
                <div class="team-member">
                    <div class="team-member-image" style="background-color: #f9c74f;">
                        <img src="assets/img/member.png" alt="Team Member 1">
                    </div>
                    <div class="team-member-info">
                        <h3>Mike Cannon-Brookes</h3>
                        <p>Co-Founder & Co-CEO</p>
                    </div>
                </div>
                <div class="team-member">
                    <div class="team-member-image" style="background-color: #90be6d;">
                        <img src="assets/img/member.png" alt="Team Member 2">
                    </div>
                    <div class="team-member-info">
                        <h3>Scott Farquhar</h3>
                        <p>Co-Founder & Co-CEO</p>
                    </div>
                </div>
                <div class="team-member">
                    <div class="team-member-image" style="background-color: #f8961e;">
                        <img src="assets/img/member.png" alt="Team Member 3">
                    </div>
                    <div class="team-member-info">
                        <h3>Anu Bharadwaj</h3>
                        <p>President</p>
                    </div>
                </div>
                <div class="team-member">
                    <div class="team-member-image" style="background-color: #f8961e;">
                        <img src="assets/img/member.png" alt="Team Member 4">
                    </div>
                    <div class="team-member-info">
                        <h3>Anu Bharadwaj</h3>
                        <p>President</p>
                    </div>
                </div>
            </div>
        </section>

        <section id="values">
            <h2>Our Values</h2>
            <p>Our values guide everything we do. We believe in [list key values, e.g., "integrity, creativity, and excellence"]. These principles are at the heart of our mission and shape the way we approach every project, big or small.</p>
        </section>

        <section id="why-choose-us">
            <h2>Why Choose Us?</h2>
            <p>Choosing us means selecting a partner who is as passionate about your success as you are. With a proven track record of delivering exceptional experiences, we go above and beyond to exceed your expectations. Our commitment to [mention key differentiators, e.g., "innovation, customer satisfaction, and attention to detail"] sets us apart in the industry.</p>
        </section>
    </div>

    <section class="contact">
        <div class="container">
            <h2>Contact Us</h2>
            <p>Ready to bring your vision to life? <a href="mailto:info@example.com">Get in touch</a> with us today!</p>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; [Year] [Your Name or Company Name]. All rights reserved.</p>
        </div>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
