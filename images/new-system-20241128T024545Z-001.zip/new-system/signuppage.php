<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f7f7;
        }

        .registration-container {
            max-width: 450px;
            margin: 40px auto;
            padding: 30px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .registration-header {
            text-align: center;
        }

        .logo {
            width: 50px;
            height: auto;
            margin-bottom: 10px;
        }

        .registration-header h2 {
            margin: 0;
            font-size: 20px;
        }

        .registration-content {
            text-align: center;
        }

        .registration-content h3 {
            margin-bottom: 5px;
            font-size: 18px;
        }

        .registration-content p {
            margin: 0 0 20px;
            color: gray;
        }

        .steps {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
            border-bottom: 1px solid lightgray;
            padding-bottom: 10px;
        }

        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            font-size: 12px;
            color: gray;
        }

        .step-circle {
            width: 24px;
            height: 24px;
            display: flex;
            justify-content: center;
            align-items: center;
            border: 1px solid lightgray;
            border-radius: 50%;
            background-color: white;
            font-size: 12px;
            color: lightgray;
            margin-bottom: 4px;
        }

        .step.active .step-circle {
            background-color: black;
            color: white;
        }

        .registration-form {
            display: none;
            flex-direction: column;
            position: relative;
        }

        .registration-form.active {
            display: block;
        }

        .form-group {
            position: relative;
            margin-bottom: 20px;
        }

        .registration-form input,
        .registration-form select {
            width: 100%;
            padding: 12px;
            font-size: 14px;
            border: 1px solid #ddd;
            border-radius: 4px;
            outline: none;
            transition: border-color 0.2s ease-in-out;
            margin: 0 auto;
            display: block;
            box-sizing: border-box; /* Ensure consistent padding and border */
        }

        .registration-form input:focus,
        .registration-form select:focus {
            border-color: #333;
        }

        .registration-form label {
            position: absolute;
            top: 10px;
            left: 15px;
            font-size: 14px;
            color: gray;
            pointer-events: none;
            transition: all 0.2s ease-in-out;
        }

        .registration-form input:focus + label,
        .registration-form input:not(:placeholder-shown) + label,
        .registration-form select:focus + label,
        .registration-form select:not(:placeholder-shown) + label {
            top: -10px;
            left: 8px;
            font-size: 12px;
            color: black;
            background-color: white;
            padding: 0 4px;
        }

        .form-navigation {
            display: center;
            justify-content: space-between;
            margin-bottom: 5%;
        }

        .next-btn {
            background-color: #d3d3d3;
            color: black;
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;

        }

        .next-btn:hover {
            background-color: #5082b7;
            color: white;
        }

        .signin-link {
            gap: 10px;
            margin-top: 20px;
            font-size: 12px;
            color: gray;
        }

        .signin-link a {
            color: #2e6bff;
            text-decoration: none;
        }

        .form-group input[type="checkbox"] {
            width: auto;
            margin-top: -13px;
            margin-right: 100%;
            display: left; /* Display label inline for checkbox */
        }



        .agree-label {
            margin-top: 9px;
            display: left;
            margin-left: 9px; /* Adjust this value to move the label horizontally */
        }

                .terms-link {
            position: relative;
            left: -73px;
            top: -16px; /* Adjust the value as needed */
            color: #2e6bff; /* Keeps the link color */
            text-decoration: none; /* Remove underline if not desired */
            font-size: 14px;
        }

    </style>
</head>
<body>
    <div class="registration-container">
        <div class="registration-header">
            <img src="images/sample.jpg" alt="Name Logo" class="logo">
        </div>
        <div class="registration-content">
            <h3>Registration</h3>
            <p>Create your account</p>


            <!-- Combined Form -->
            <form class="registration-form active" action="register.php" method="post">
                <!-- Step 1: Name -->
                <div class="form-group" data-step="1">
                    <input type="text" id="first-name" name="first_name" required placeholder=" ">
                    <label for="first-name">First Name</label>
                </div>
                <div class="form-group" data-step="1">
                    <input type="text" id="last-name" name="last_name" required placeholder=" ">
                    <label for="last-name">Last Name</label>
                </div>

                <!-- Step 2: User Details -->
                <div class="form-group" data-step="2">
                    <select id="sex" name="sex" required>
                        <option value="" disabled selected>Select your sex</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                    <label for="sex">*Sex</label>
                </div>
                <div class="form-group" data-step="2">
                    <input type="date" id="birthdate" name="birthdate" required placeholder="mm/dd/yyyy">
                    <label for="birthdate">*Birthdate</label>
                </div>
                <div class="form-group" data-step="2">
                    <input type="number" id="age" name="age" readonly placeholder=" ">
                    <label for="age">*Age</label>
                </div>

                <!-- Step 3: Address -->
                <div class="form-group" data-step="3">
                    <input type="text" id="building" name="building" placeholder=" ">
                    <label for="building">Blk / Bldg No (Optional)</label>
                </div>
                <div class="form-group" data-step="3">
                    <input type="text" id="street" name="street" required placeholder=" ">
                    <label for="street">*Street</label>
                </div>
                <div class="form-group" data-step="3">
                    <input type="text" id="barangay" name="barangay" required placeholder=" ">
                    <label for="barangay">*Barangay</label>
                </div>
                <div class="form-group" data-step="3">
                    <input type="text" id="city" name="city" required placeholder=" ">
                    <label for="city">*City</label>
                </div>
                <div class="form-group" data-step="3">
                    <select id="province" name="province" required>
                    <option value="" disabled selected>Select Province</option>
            <option value="abu">Abu</option>
            <option value="agusan del norte">Agusan del Norte</option>
            <option value="agusan del sur">Agusan del Sur</option>
            <option value="apayao">Apayao</option>
            <option value="aurora">Aurora</option>
            <option value="basilan">Basilan</option>
            <option value="bataan">Bataan</option>
            <option value="batanes">Batanes</option>
            <option value="batangas">Batangas</option>
            <option value="benguet">Benguet</option>
            <option value="biliran">Biliran</option>
            <option value="bohol">Bohol</option>
            <option value="bukidnon">Bukidnon</option>
            <option value="bulacan">Bulacan</option>
            <option value="cagayan">Cagayan</option>
            <option value="camarines norte">Camarines Norte</option>
            <option value="camarines sur">Camarines Sur</option>
            <option value="camiguin">Camiguin</option>
            <option value="capiz">Capiz</option>
            <option value="catanduanes">Catanduanes</option>
            <option value="cavite">Cavite</option>
            <option value="cebu">Cebu</option>
            <option value="comval">Comval</option>
            <option value="davao de oro">Davao de Oro</option>
            <option value="davao del norte">Davao del Norte</option>
            <option value="davao del sur">Davao del Sur</option>
            <option value="davao occidental">Davao Occidental</option>
            <option value="dinagat islands">Dinagat Islands</option>
            <option value="Eastern Samar">Eastern Samar</option>
            <option value="guimaras">Guimaras</option>
            <option value="ifugao">Ifugao</option>
            <option value="ilocos norte">Ilocos Norte</option>
            <option value="ilocos sur">Ilocos Sur</option>
            <option value="iloilo">Iloilo</option>
            <option value="isabela">Isabela</option>
            <option value="kalinga">Kalinga</option>
            <option value="kalibo">Kalibo</option>
            <option value="laguna">Laguna</option>
            <option value="la union">La Union</option>
            <option value="lantawan">Lantawan</option>
            <option value="leite">Leite</option>
            <option value="lanao del norte">Lanao del Norte</option>
            <option value="lanao del sur">Lanao del Sur</option>
            <option value="leyte">Leyte</option>
            <option value="maguindanao">Maguindanao</option>
            <option value="marinduque">Marinduque</option>
            <option value="masbate">Masbate</option>
            <option value="mindoro occidental">Mindoro Occidental</option>
            <option value="mindoro oriental">Mindoro Oriental</option>
            <option value="misamis occidental">Misamis Occidental</option>
            <option value="misamis oriental">Misamis Oriental</option>
            <option value="mountain province">Mountain Province</option>
            <option value="nueva ecija">Nueva Ecija</option>
            <option value="nueva vizcaya">Nueva Vizcaya</option>
            <option value="occidental mindoro">Occidental Mindoro</option>
            <option value="oriental mindoro">Oriental Mindoro</option>
            <option value="palawan">Palawan</option>
            <option value="pangasinan">Pangasinan</option>
            <option value="samar">Samar</option>
            <option value="sorsogon">Sorsogon</option>
            <option value="southern leyte">Southern Leyte</option>
            <option value="sultan kudarat">Sultan Kudarat</option>
            <option value="sulu">Sulu</option>
            <option value="tarlac">Tarlac</option>
            <option value="tawi-tawi">Tawi-Tawi</option>
            <option value="zambales">Zambales</option>
            <option value="zamboanga del norte">Zamboanga del Norte</option>
            <option value="zamboanga del sur">Zamboanga del Sur</option>
            <option value="zamboanga sibugay">Zamboanga Sibugay</option>
                    </select>
                    <label for="province">Province</label>
                </div>

                <!-- Step 4: Account Credentials -->
                <div class="form-group" data-step="4">
                    <input type="email" id="email" name="email" required placeholder=" "
                        pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$"
                        title="Please enter a valid email address, e.g., user@example.com">
                    <label for="email">Email</label>
                </div>
                <div class="form-group" data-step="4">
                    <input type="text" id="username" name="username" required placeholder=" ">
                    <label for="username">Username</label>
                </div>
                <div class="form-group" data-step="4">
                    <input type="password" id="password" name="password" required placeholder=" ">
                    <label for="password">Password</label>
                </div>
                <div class="form-group">
                    <input type="checkbox" id="agree" name="agree" required>
                    <label for="agree" class="agree-label">I agree to</label> 
                    <a href="Sample-Privacy-Policy-Template.pdf" class="terms-link">privacy policy and terms</a>
                </div>
                <div class="form-navigation">
                    <button type="submit" class="next-btn">Sign Up</button>
                </div>
            </form>

            <p class="signin-link">Already have an account? <a href="index.php">Sign in instead</a></p>
        </div>
    </div>

    <script>
        const nextButtons = document.querySelectorAll('.next-btn');
        const previousButtons = document.querySelectorAll('.previous-btn');
        const steps = document.querySelectorAll('.step');
        const forms = document.querySelectorAll('.registration-form');

        let currentStep = 1;

        function showStep(step) {
            forms.forEach(form => {
                form.classList.remove('active');
                if (form.getAttribute('data-step') == step) {
                    form.classList.add('active');
                }
            });

            steps.forEach(stepEl => {
                stepEl.classList.remove('active');
                if (stepEl.getAttribute('data-step') == step) {
                    stepEl.classList.add('active');
                }
            });

            currentStep = step;
        }

        nextButtons.forEach(button => {
            button.addEventListener('click', () => {
                if (currentStep < steps.length) {
                    showStep(currentStep + 1);
                }
            });
        });

        previousButtons.forEach(button => {
            button.addEventListener('click', () => {
                if (currentStep > 1) {
                    showStep(currentStep - 1);
                }
            });
        });

        document.getElementById('birthdate').addEventListener('change', function() {
    const birthdate = new Date(this.value);
    const today = new Date();
    let age = today.getFullYear() - birthdate.getFullYear();
    const monthDiff = today.getMonth() - birthdate.getMonth();

    // Adjust age if the birthdate hasn't occurred yet this year
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthdate.getDate())) {
        age--;
    }

    // Set the age value in the age input field
    document.getElementById('age').value = age >= 0 ? age : '';

    // If a valid birthdate is entered, add the class for hover effect
    if (this.value) {
        document.querySelector('.registration-container').classList.add('birthdate-entered');
    } else {
        document.querySelector('.registration-container').classList.remove('birthdate-entered');
    }
});


    </script>
</body>
</html>
