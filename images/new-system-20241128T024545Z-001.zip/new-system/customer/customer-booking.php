<?php
session_start();
include 'db_connect.php'; // Include the database connection

// Check if the user is logged in
if (!isset($_SESSION['first_name'])) {
    header("Location: customer-loginpage.php"); // Redirect to login page if not logged in
    exit();
}

$first_name = htmlspecialchars($_SESSION['first_name']); // Retrieve and sanitize the first_name

// Fetch entertainers from the database
$sql = "SELECT entertainer_id, profile_image, title FROM entertainer_account";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Dashboard</title>
    <link rel="stylesheet" href="style2.css">
    <link rel="stylesheet" href="cardstyle.css">
    
</head>
<style>
    .card-box {
        background-color: #F0F8FF;
        border: 2px solid #87CEFA;
        cursor: pointer; /* Make the card clickable */
    }

    .card-box h3 {
        background-color: #F0FFFF;
        color: black;
        padding: 5px;
        border-radius: 3px;
        opacity: 0.5;
    }

    .card-box:hover {
        background-color: #E0FFFF;
    }

    .nav-items {
    display: flex;
    gap: 30px; /* Space between items */
    margin-right: 80px; /* Adjust this value to increase space from the profile image */
}

.nav-items a {
    text-decoration: none;
    color: white; /* Adjust color as needed */
    padding: 10px;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.nav-items a:hover {
    background-color: #87CEFA; /* Light blue background on hover */
    text-decoration: none; /* Ensure no underline on hover */
    color: black;
}

.dropbtn {
    background: none; /* Remove default button background */
    border: none; /* Remove default button border */
    cursor: pointer; /* Pointer cursor on hover */
}

.dropbtn img {
    width: 40px; /* Adjust image size */
    height: auto; /* Maintain aspect ratio */
}

.navbar-brand img {
            width: 40px; /* Adjust size as needed */
            height: 40px; /* Adjust size as needed */
            border-radius: 40%; /* Make the image circular */
        }
</style>

<body>
    <header>
    <a class="navbar-brand" href="#">
            <img src="../images/logo.jpg" alt="Brand Logo"> <!-- Update the path to your image -->
        </a>
        <nav>
        <div class="nav-items">
                <a href="customer-booking.php">Book Appointment</a>
                <a href="customer-appointment.php">My Appointment</a>
            </div>
        <div class="dropdown" id="dropdown">
                <button class="dropbtn" onclick="toggleDropdown()">
                    <img src="../images/sample.jpg" alt="Profile"> <!-- Replace with your image -->
                </button>
                <div class="dropdown-content" id="dropdown-content">
                    <a href="customer-profile.php">View Profile</a>
                    <a href="logout.php">Logout</a> <!-- Logout link pointing to logout.php -->
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="welcome-message">
            <h1>Welcome, <?php echo $first_name; ?>!</h1>
            <p>We’re glad to have you here. Let’s get started!</p>
        </section>
    </main>

    <div class="container">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="card-box" onclick="redirectToBooking(<?php echo $row['entertainer_id']; ?>)">
                    <img src="../images/<?php echo htmlspecialchars($row['profile_image']); ?>" alt="<?php echo htmlspecialchars($row['title']); ?>">
                    <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No entertainers available at the moment.</p>
        <?php endif; ?>
    </div>

    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown');
            const dropdownContent = document.getElementById('dropdown-content');

            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            } else {
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });

                dropdown.classList.add('show');
            }
        }

        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn') && !event.target.matches('.dropbtn img')) {
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });
            }
        }

        function redirectToBooking(entertainerId) {
            window.location.href = `next-page.php?entertainer_id=${entertainerId}`;
        }
    </script>
</body>
</html>

<?php $conn->close(); ?>
