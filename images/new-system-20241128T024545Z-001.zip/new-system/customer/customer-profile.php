
<?php

session_start();

// Check if the user is logged in
if (!isset($_SESSION['first_name'])) {
    header("Location: entertainer-loginpage.php"); // Redirect to login page if not logged in
    exit();
}

$first_name = htmlspecialchars($_SESSION['first_name']); // Retrieve and sanitize the first_name
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Dashboard</title>
    <link rel="stylesheet" href="style2.css">

</head>
<style>
/* Main Content Styles */
.main-content {
            margin-left: 50px;
            padding: 20px;
            transition: margin-left 0.3s ease;
            margin-top: 1px; /* Add a top margin to create space between the header and the content */
        }

        .tabs {
            display: flex;
            border-bottom: 1px solid #ddd;
            margin-bottom: 20px;
        }

        .tabs a {
            padding: 10px 20px;
            text-decoration: none;
            color: #333;
            border-bottom: 2px solid transparent;
            transition: border-bottom 0.3s ease, background-color 0.3s ease, color 0.3s ease;
        }

        .tabs a.active {
            border-bottom: 2px solid #004080;
            color: #004080;
            background-color: #f2f2f2;
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .form-group {
            margin-bottom: 15px;
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 5px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .form-group input[type="password"] {
            position: relative;
            padding-right: 40px;
        }

        .toggle-password {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
        }

        /* Buttons */
        .button-group {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }

        .btn {
            padding: 10px 20px;
            border-radius: 5px;
            border: none;
            cursor: pointer;
        }

        .btn-primary {
            background-color: #004080;
            color: #fff;
        }

        .btn-primary:hover {
            background-color: #003366;
        }

        .btn-secondary {
            background-color: #ddd;
            color: #333;
        }

        .btn-secondary:hover {
            background-color: #ccc;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            overflow: auto;
        }

        .modal-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .main-content {
                margin-left: 0;
            }

            .tabs a {
                flex: 1;
                text-align: center;
            }

            .form-group {
                flex: 1 1 100%;
            }
        }

/* Ensure form-group is properly spaced and input fields don't touch edges */
.form-group {
    margin-bottom: 15px; /* Space between each form group */
}

.form-group label {
    margin-bottom: 5px;
    display: block;
}

.form-group input,
.form-group select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    font-size: 16px;
    box-sizing: border-box; /* Include padding in width calculation */
}

.form-row {
    display: flex;
    gap: 20px; /* Space between horizontal items */
    margin-bottom: 15px; /* Space below each row */
}

.form-row .form-group {
    flex: 1;
    min-width: 0; /* Prevent flex items from growing too large */
}

.form-row .form-group input,
.form-row .form-group select {
    width: 100%;
}

/* Custom length for the Province input */
.input-province {
    width: 100%; /* Ensures input box takes the full width of its container */
    max-width: 500px; /* Adjust this value to control the maximum width of the input box */
    box-sizing: border-box; /* Ensures padding and border are included in the width calculation */
}

/* Make the label text size smaller in the Account tab */
#account .form-group label {
    font-size: 12px; /* Adjust this value to your preferred size */
}

 /* Horizontal alignment of New Password and Confirm New Password */
.security-form .form-row {
    display: flex;
    gap: 20px; /* Space gap between each pair */
    margin-bottom: 15px; /* Space below the row */
}

.security-form .form-group {
    flex: 1; /* Allow form-group to take available space */
    min-width: 0; /* Prevent input from stretching too far */
}

.security-form .form-group input {
    width: 100%; /* Full width of the container */
    max-width: 100%; /* Ensure it doesn't exceed container width */
    box-sizing: border-box; /* Include padding and border in the width */
    padding: 10px; /* Ensure padding inside the input box */
}

.security-form .form-group input.small-input {
    width: 80%; /* Make the current password input box smaller */
    max-width: 510px; /* Maximum width for smaller input box */
}

.security-form .form-group label {
    font-size: 14px; /* Adjust font size of labels if needed */
}
</style>
<body>
    <header>
        <div class="logo">Logo</div>
        <nav>
            <div class="dropdown" id="dropdown">
                <button class="dropbtn" onclick="toggleDropdown()">
                    <img src="../images/sample.jpg" alt="Profile"> <!-- Replace with your image -->
                </button>
                <div class="dropdown-content" id="dropdown-content">
                    <a href="customer-profile.php">View Profile</a>
                    <a href="customer-booking.php">Book Appointment</a>
                    <a href="customer-appointment.php">My Appointment</a>
                    <a href="logout.php">Logout</a> <!-- Logout link pointing to logout.php -->
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="welcome-message">
            <h1>Welcome, <?php echo $first_name; ?>!</h1>
            <p>We’re glad to have you here. Let’s get started!</p>
        </section>
    </main>

    <div class="main-content">

    <div class="tabs">
        <a href="#account" id="account-tab" class="active" aria-controls="account">Account</a>
        <a href="#security" id="security-tab" aria-controls="security">Security</a>
    </div>

    <div id="account" class="tab-content active">
    <h3>Account Details</h3>
    <hr>
    <form action="/update-account" method="POST" class="account-form">
    <!-- Existing form fields -->

    <!-- Horizontal alignment of First Name and Last Name -->
    <div class="form-row">
        <div class="form-group">
            <label for="firstName">First Name</label>
            <input type="text" id="firstName" name="firstName" required>
        </div>
        <div class="form-group">
            <label for="lastName">Last Name</label>
            <input type="text" id="lastName" name="lastName" required>
        </div>
    </div>

    <!-- Horizontal alignment of Age and Birthdate -->
    <div class="form-row">
        <div class="form-group">
            <label for="age">Age</label>
            <input type="number" id="age" name="age" required>
        </div>
        <div class="form-group">
            <label for="birthdate">Birthdate</label>
            <input type="date" id="birthdate" name="birthdate" required>
        </div>
    </div>

    <!-- Horizontal alignment of Gender and Email -->
    <div class="form-row">
        <div class="form-group">
            <label for="gender">Gender</label>
            <select id="gender" name="gender" required>
                <option value="" disabled selected>Select Gender</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
            </select>
        </div>
        <div class="form-group">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
        </div>
    </div>
    <h4 style="color: #D3D3D3;">Address</h4>
    <!-- Horizontal alignment of Block Number and Street -->
    <div class="form-row">
        <div class="form-group">
            <label for="blockNumber">Block / Bldg No.</label>
            <input type="text" id="blockNumber" name="blockNumber" required>
        </div>
        <div class="form-group">
            <label for="street">Street</label>
            <input type="text" id="street" name="street" required>
        </div>
    </div>

    <!-- Horizontal alignment of Barangay and City -->
    <div class="form-row">
        <div class="form-group">
            <label for="barangay">Barangay</label>
            <input type="text" id="barangay" name="barangay" required>
        </div>
        <div class="form-group">
            <label for="city">City</label>
            <input type="text" id="city" name="city" required>
        </div>
    </div>

    <!-- Dropdown for Province -->
    <div class="form-group">
        <label for="province">Province</label>
        <select id="province" name="province" class="input-province" required>
            <option value="" disabled selected>Select Province</option>
            <option value="abu">Abu</option>
            <option value="agusan del norte">Agusan del Norte</option>
            <option value="agusan del sur">Agusan del Sur</option>
            <option value="apayao">Apayao</option>
            <option value="aurora">Aurora</option>
            <option value="basilan">Basilan</option>
            <option value="bataan">Bataan</option>
            <option value="batanes">Batanes</option>
            <option value="batangas">Batangas</option>
            <option value="benguet">Benguet</option>
            <option value="biliran">Biliran</option>
            <option value="bohol">Bohol</option>
            <option value="bukidnon">Bukidnon</option>
            <option value="bulacan">Bulacan</option>
            <option value="cagayan">Cagayan</option>
            <option value="camarines norte">Camarines Norte</option>
            <option value="camarines sur">Camarines Sur</option>
            <option value="camiguin">Camiguin</option>
            <option value="capiz">Capiz</option>
            <option value="catanduanes">Catanduanes</option>
            <option value="cavite">Cavite</option>
            <option value="cebu">Cebu</option>
            <option value="comval">Comval</option>
            <option value="davao de oro">Davao de Oro</option>
            <option value="davao del norte">Davao del Norte</option>
            <option value="davao del sur">Davao del Sur</option>
            <option value="davao occidental">Davao Occidental</option>
            <option value="dinagat islands">Dinagat Islands</option>
            <option value="Eastern Samar">Eastern Samar</option>
            <option value="guimaras">Guimaras</option>
            <option value="ifugao">Ifugao</option>
            <option value="ilocos norte">Ilocos Norte</option>
            <option value="ilocos sur">Ilocos Sur</option>
            <option value="iloilo">Iloilo</option>
            <option value="isabela">Isabela</option>
            <option value="kalinga">Kalinga</option>
            <option value="kalibo">Kalibo</option>
            <option value="laguna">Laguna</option>
            <option value="la union">La Union</option>
            <option value="lantawan">Lantawan</option>
            <option value="leite">Leite</option>
            <option value="lanao del norte">Lanao del Norte</option>
            <option value="lanao del sur">Lanao del Sur</option>
            <option value="leyte">Leyte</option>
            <option value="maguindanao">Maguindanao</option>
            <option value="marinduque">Marinduque</option>
            <option value="masbate">Masbate</option>
            <option value="mindoro occidental">Mindoro Occidental</option>
            <option value="mindoro oriental">Mindoro Oriental</option>
            <option value="misamis occidental">Misamis Occidental</option>
            <option value="misamis oriental">Misamis Oriental</option>
            <option value="mountain province">Mountain Province</option>
            <option value="nueva ecija">Nueva Ecija</option>
            <option value="nueva vizcaya">Nueva Vizcaya</option>
            <option value="occidental mindoro">Occidental Mindoro</option>
            <option value="oriental mindoro">Oriental Mindoro</option>
            <option value="palawan">Palawan</option>
            <option value="pangasinan">Pangasinan</option>
            <option value="samar">Samar</option>
            <option value="sorsogon">Sorsogon</option>
            <option value="southern leyte">Southern Leyte</option>
            <option value="sultan kudarat">Sultan Kudarat</option>
            <option value="sulu">Sulu</option>
            <option value="tarlac">Tarlac</option>
            <option value="tawi-tawi">Tawi-Tawi</option>
            <option value="zambales">Zambales</option>
            <option value="zamboanga del norte">Zamboanga del Norte</option>
            <option value="zamboanga del sur">Zamboanga del Sur</option>
            <option value="zamboanga sibugay">Zamboanga Sibugay</option>
        </select>
    </div>

    <div class="button-group">
        <button type="submit" class="btn btn-primary">Save Changes</button>
        <button type="reset" class="btn btn-secondary">Reset</button>
    </div>
</form>
</div>


<div id="security" class="tab-content">
    <h3>Change Password</h3>
    <hr>
    <form action="/update-password" method="POST" class="security-form">
        <div class="form-group">
            <label for="currentPassword">Current Password</label>
            <input type="password" id="currentPassword" name="currentPassword" class="small-input" required>
        </div>

        <!-- Horizontal alignment of New Password and Confirm New Password -->
        <div class="form-row">
            <div class="form-group">
                <label for="newPassword">New Password</label>
                <input type="password" id="newPassword" name="newPassword" required>
            </div>
            <div class="form-group">
                <label for="confirmPassword">Confirm New Password</label>
                <input type="password" id="confirmPassword" name="confirmPassword" required>
            </div>
        </div>

        <div class="button-group">
            <button type="submit" class="btn btn-primary">Update Password</button>
        </div>
    </form>
</div>
</div>


    <script>

        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown');
            const dropdownContent = document.getElementById('dropdown-content');

            // Toggle the visibility of the dropdown content
            if (dropdown.classList.contains('show')) {
                dropdown.classList.remove('show');
            } else {
                // Close any other open dropdowns
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });

                dropdown.classList.add('show');
            }
        }

        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn') && !event.target.matches('.dropbtn img')) {
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });
            }
        }

         // Toggle tab content
    const tabs = document.querySelectorAll('.tabs a');
    const tabContents = document.querySelectorAll('.tab-content');

    tabs.forEach(tab => {
        tab.addEventListener('click', function (e) {
            e.preventDefault();
            tabs.forEach(t => t.classList.remove('active'));
            tabContents.forEach(tc => tc.classList.remove('active'));

            this.classList.add('active');
            document.querySelector(this.getAttribute('href')).classList.add('active');
        });
    });
    </script>
</body>
</html>