<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['first_name'])) {
    header("Location: customer-loginpage.php"); // Redirect to login page if not logged in
    exit();
}

$first_name = htmlspecialchars($_SESSION['first_name']); // Retrieve and sanitize the first_name

// Database connection
$servername = "localhost"; // Update with your server name
$username = "root"; // Update with your database username
$password = ""; // Update with your database password
$dbname = "db_booking_system"; // Update with your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch data from booking_report, joining with entertainer_account
$sql = "SELECT br.*, e.title AS entertainer_title 
        FROM booking_report br 
        JOIN entertainer_account e ON br.entertainer_id = e.entertainer_id 
        WHERE br.customer_id = ?"; // Adjust the query as necessary
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['customer_id']); // Assuming you have customer_id in session
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Dashboard</title>
    <link rel="stylesheet" href="style2.css">

</head>
<style>
         body {
            overflow: auto; /* Only show scrollbar when necessary */
        }

        .content {
            overflow: hidden; /* Hide scrollbar initially */
        }

        /* Show scrollbar when content overflows */
        .content::-webkit-scrollbar {
            width: 0;
            height: 0;
        }

        .content {
            overflow-y: auto;
        }

            /* Schedule List Styles */
        .content {
            display: flex;
            justify-content: center; /* Center horizontally */
            align-items: flex-start; /* Align items at the top */
            margin-left: 100px;
            padding: 20px;
            padding-top: 10px; /* Give some space below the header */
            background-color: #f2f2f2;
            min-height: 100vh;
        }

        .schedule-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: 100%; /* Ensure it takes full width of the parent */
            max-width: 1200px; /* Set a maximum width for larger screens */
        }


        .schedule-container input[type="text"] {
            padding: 10px;
            width: 40%;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .schedule-header {
            background-color: #fff;
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-radius: 10px 10px 0 0;
        }

        .schedule-header h2 {
            margin: 0;
            font-size: 18px;
            color: #333;
        }

        .schedule-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        .schedule-table th, .schedule-table td {
            text-align: left;
            padding: 10px;
            border-bottom: 1px solid #e0e0e0;
            color: #333;
        }

        .schedule-table th {
            background-color: #f8f8f8;
            font-weight: normal;
        }

        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .pagination select {
            padding: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .pagination span {
            color: #888;
        }

        .pagination-controls {
            display: flex;
            gap: 5px;
        }

        .pagination-controls img {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            .header {
                width: 100%;
                left: 0;
            }

            .content {
                margin-left: 0;
                padding-top: 60px; /* Adjust padding for smaller screens */
                padding: 10px; /* Add padding to the content */
            }

            .schedule-container {
                width: 100%; /* Full width for small screens */
                padding: 10px; /* Adjust padding */
            }

            .schedule-header input[type="text"] {
                width: 100%; /* Full width input for smaller screens */
            }

            .pagination {
                flex-direction: row; /* Stack pagination controls vertically */
                align-items: flex-start;
            }

            .pagination-controls {
                width: 100%;
                justify-content: space-between; /* Space out controls */
            }
        }


        .button-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .schedule-header .refresh-btn
         {
            width: 40px;
            height: 40px;
            border: none;
            background-color: white;
            color: black;
            font-size: 18px;
            border-radius: 50%;
            cursor: pointer;
            transition: background-color 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .schedule-header .refresh-btn:hover
        {
            background-color: #f0fff0;
        }

        #status-select {
            padding: 10px;
            width: 30%;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 20px; /* Space between dropdown and table */
        }

        .nav-items {
            display: flex;
            gap: 30px; /* Space between items */
            margin-right: 80px; /* Adjust this value to increase space from the profile image */
        }

        .nav-items a {
            text-decoration: none;
            color: white; /* Adjust color as needed */
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .nav-items a:hover {
            background-color: #87CEFA; /* Light blue background on hover */
            text-decoration: none; /* Ensure no underline on hover */
            color: black;
        }

        .dropbtn {
            background: none; /* Remove default button background */
            border: none; /* Remove default button border */
            cursor: pointer; /* Pointer cursor on hover */
        }

        .dropbtn img {
            width: 40px; /* Adjust image size */
            height: auto; /* Maintain aspect ratio */
        }

        .navbar-brand img {
                    width: 40px; /* Adjust size as needed */
                    height: 40px; /* Adjust size as needed */
                    border-radius: 40%; /* Make the image circular */
                }

        .status-selection {
            margin-top: 20px;
        }

        .status-selection label {
            margin-right: 10px;
        }

        .status-selection select {
            padding: 10px;
            margin-right: 10px;
        }

        .edit-btn {
            background-color: blue; /* Blue background */
            color: white; /* White text */
            border: none; /* Remove border */
            padding: 10px 15px; /* Add padding */
            border-radius: 5px; /* Rounded corners */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s; /* Smooth transition */
        }

        .edit-btn:hover {
            background-color: darkblue; /* Darker blue on hover */
        }

        .cancel-btn {
            background-color: red; /* Red background */
            color: white; /* White text */
            border: none; /* Remove border */
            padding: 10px 15px; /* Add padding */
            border-radius: 5px; /* Rounded corners */
            cursor: pointer; /* Pointer cursor on hover */
            transition: background-color 0.3s; /* Smooth transition */
        }

        .cancel-btn:hover {
            background-color: darkred; /* Darker red on hover */
        }


</style>
<body>
    <header>
    <a class="navbar-brand" href="#">
            <img src="../images/logo.jpg" alt="Brand Logo"> <!-- Update the path to your image -->
        </a>
        <nav>
        <div class="nav-items">
                <a href="customer-booking.php">Book Appointment</a>
                <a href="customer-appointment.php">My Appointment</a>
            </div>
            <div class="dropdown" id="dropdown">
                <button class="dropbtn" onclick="toggleDropdown()">
                    <img src="../images/sample.jpg" alt="Profile">
                </button>
                <div class="dropdown-content" id="dropdown-content">
                    <a href="customer-profile.php">View Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </nav>
    </header>

    <main>
        <section class="welcome-message">
            <h1>Welcome, <?php echo $first_name; ?>!</h1>
            <p>We’re glad to have you here. Let’s get started!</p>
        </section>
    </main>

    <div class="content">
        <div class="schedule-container">
            <h2>Appointments</h2>

                    <!-- Status Selection -->
        <div class="status-selection">
        <select id="status-select" onchange="filterAppointments()">
                <option value="">Select All</option>
                <option value="Approved">Approved</option>
                <option value="Pending">Pending</option>
                <option value="Declined">Declined</option>
            </select>
        </div>

        <div id="no-appointments-message" style="display:none; color: red;">
            No appointments found for the selected status.
        </div>

            <table class="schedule-table">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Time Start</th>
                        <th>Time End</th>
                        <th>Entertainer</th>
                        <th>Price</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody id="schedule-table-body">
                <?php if ($result->num_rows > 0): ?>
                    <?php foreach ($result as $row): ?>
                        <tr data-status="<?php echo htmlspecialchars($row['status']); ?>">
                            <td><?php echo htmlspecialchars($row['date_schedule']); ?></td>
                            <td><?php 
                                $timeStart = DateTime::createFromFormat('H:i:s', $row['time_start']);
                                echo $timeStart ? $timeStart->format('h:i A') : ''; 
                            ?></td>
                            <td><?php 
                                $timeEnd = DateTime::createFromFormat('H:i:s', $row['time_end']);
                                echo $timeEnd ? $timeEnd->format('h:i A') : ''; 
                            ?></td>
                            <td><?php echo htmlspecialchars($row['entertainer_title']); ?></td>
                            <td><?php echo htmlspecialchars($row['price_offer']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                            <td>
                            <?php if (htmlspecialchars($row['status']) === 'Approved'): ?>
                    <button class='edit-btn' onclick='downPayment(<?php echo $row['book_id']; ?>)'>Down Payment</button>
                <?php else: ?>
                                <button class='edit-btn' onclick='editAppointment(<?php echo $row['book_id']; ?>)'>Edit</button>
                                <button class='cancel-btn' onclick='cancelAppointment(<?php echo $row['book_id']; ?>)'>Cancel</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <tr>
                        <td colspan="7" style="text-align: center; background-color: #f0f0f0; color: gray;">
                            No appointments found for the selected status.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

   <!-- GCash Payment Modal -->
<div id="gcash-modal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background-color: rgba(0,0,0,0.5); justify-content: center; align-items: center;">
    <div style="background: white; padding: 20px; border-radius: 8px; width: 300px; text-align: center;">
        <h2>Down Payment via GCash</h2>
        
        <!-- QR Code Image -->
        <img src="../images/qrcode.png" alt="GCash QR Code" style="width: 50%; margin-bottom: 10px;"/>

        <p>Scan the QR code or enter your GCash number for the down payment.</p>
        <input type="text" id="gcash-number" placeholder="GCash Number" required style="width: 100%; margin-bottom: 10px; padding: 8px;"/>
        <input type="number" id="amount" placeholder="Amount" required style="width: 100%; margin-bottom: 10px; padding: 8px;"/>
        <button onclick="processDownPayment()">Pay Now</button>
        <button onclick="closeGcashModal()">Cancel</button>
    </div>
</div>

    <script>
        function toggleDropdown() {
            const dropdown = document.getElementById('dropdown');
            const dropdownContent = document.getElementById('dropdown-content');
            dropdown.classList.toggle('show');
        }
        window.onclick = function(event) {
            if (!event.target.matches('.dropbtn') && !event.target.matches('.dropbtn img')) {
                const openDropdowns = document.querySelectorAll('.dropdown.show');
                openDropdowns.forEach(function (openDropdown) {
                    openDropdown.classList.remove('show');
                });
            }
        }

        function filterAppointments() {
        const selectedStatus = document.getElementById('status-select').value;
        const rows = document.querySelectorAll('#schedule-table-body tr[data-status]');
        let hasAppointments = false;

        rows.forEach(row => {
            const status = row.getAttribute('data-status');
            if (selectedStatus === "" || status === selectedStatus) {
                row.style.display = ""; // Show row
                hasAppointments = true; // At least one appointment matches
            } else {
                row.style.display = "none"; // Hide row
            }
        });

        // Show or hide the no appointments message
        const messageRow = document.querySelector('#schedule-table-body tr.message-row');
        if (messageRow) {
            messageRow.style.display = hasAppointments ? 'none' : ''; // Show or hide the message row
        } else if (!hasAppointments) {
            const newMessageRow = document.createElement('tr');
            newMessageRow.className = 'message-row';
            newMessageRow.innerHTML = `<td colspan="7" style="text-align: center; background-color: #f0f0f0; color: gray;">
                                            No appointments found for the selected status.
                                        </td>`;
            document.getElementById('schedule-table-body').appendChild(newMessageRow);
        }
    }

        function editAppointment(appointmentId) {
    // Logic to handle editing the appointment
    alert("Edit appointment ID: " + appointmentId);
}

function cancelAppointment(appointmentId) {
    // Logic to handle canceling the appointment
    alert("Cancel appointment ID: " + appointmentId);
}

function downPayment(appointmentId) {
    // Display the GCash modal for down payment
    const modal = document.getElementById('gcash-modal');
    modal.style.display = 'flex';
    modal.setAttribute('data-appointment-id', appointmentId); // Store the appointment ID in the modal
}

function closeGcashModal() {
    const modal = document.getElementById('gcash-modal');
    modal.style.display = 'none'; // Hide the modal
}

function processDownPayment() {
    const appointmentId = document.getElementById('gcash-modal').getAttribute('data-appointment-id');
    const gcashNumber = document.getElementById('gcash-number').value;
    const amount = document.getElementById('amount').value;

    // Simple validation
    if(!gcashNumber || !amount || amount <= 0) {
        alert('Please enter a valid GCash number and amount.');
        return;
    }

    // Simulate processing the payment
    alert(`Processing down payment of PHP ${amount} for appointment ID ${appointmentId} via GCash number ${gcashNumber}...`);
    
    // Here you could implement the API call to GCash or your payment processor

    // Close the modal after processing
    closeGcashModal();
}
    </script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>