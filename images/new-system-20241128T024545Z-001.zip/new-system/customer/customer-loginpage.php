<?php
session_start();
include 'db_connect.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to fetch customer details
    $stmt = $conn->prepare("SELECT customer_id, first_name FROM customer_account WHERE username = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($customer_id, $first_name);
        $stmt->fetch();

        // Store customer ID and first name in session
        $_SESSION['customer_id'] = $customer_id; // Add this line
        $_SESSION['first_name'] = $first_name;

        header("Location: customer-booking.php"); // Redirect to dashboard
        exit();
    } else {
        $error = "Invalid username or password";
    }

    $stmt->close();
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Login</title>
    <link rel="stylesheet" href="loginstyle.css">
    <style>
    </style>
</head>
<body>
    <div class="container">
    <form action="customer-loginpage.php" method="post">
            <h1>Customer Login</h1>
            <?php
            // Display the error message above the username field with the new font size
            if (!empty($error)) {
                echo "<p class='error-message'>$error</p>";
            }
            ?>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <a href="/forgot-password" class="forgot-password">Forgot Password?</a>
            <input type="submit" value="Login">
            <div class="links">
                <p> New on our platform? <a href="/signup">Create an Account</a></p>
            </div>
        </form>
    </div>
</body>
</html>
