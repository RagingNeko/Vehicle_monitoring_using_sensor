<?php
session_start();
include 'db_connect.php'; // Include your database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the raw POST data
    $data = json_decode(file_get_contents("php://input"), true);

    // Log received data
    error_log(print_r($data, true)); // Log the data for debugging

    // Sanitize inputs
    $customerName = htmlspecialchars($data['customerName']);
    $contactNumber = htmlspecialchars($data['contactNumber']);
    $email = htmlspecialchars($data['email']);
    $street = htmlspecialchars($data['street']);
    $barangay = htmlspecialchars($data['barangay']);
    $municipality = htmlspecialchars($data['municipality']);
    $province = htmlspecialchars($data['province']);
    $timeStart = $data['timeStart'];
    $timeEnd = $data['timeEnd'];
    $priceOffer = (float)$data['priceOffer']; // Ensure this is a float
    $entertainerId = (int)$data['entertainerId'];
    $bookingDate = $data['bookingDate'];

    // Get the customer ID from session
    $customerId = isset($_SESSION['customer_id']) ? $_SESSION['customer_id'] : null;

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO booking_report (customer_id, customer_name, contact_number, email, street, barangay, municipality, province, date_schedule, time_start, time_end, price_offer, entertainer_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
    // Check if prepare failed
    if (!$stmt) {
        error_log('Prepare failed: ' . $conn->error);
        echo json_encode(['status' => 'error', 'message' => 'Prepare failed: ' . $conn->error]);
        exit();
    }

    // Set the default status
    $status = 'pending';

    // Bind parameters
    $stmt->bind_param("issssssssssiss", $customerId, $customerName, $contactNumber, $email, $street, $barangay, $municipality, $province, $bookingDate, $timeStart, $timeEnd, $priceOffer, $entertainerId, $status);
    
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        error_log('Execute failed: ' . $stmt->error);
        echo json_encode(['status' => 'error', 'message' => 'Execute failed: ' . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
}




?>
